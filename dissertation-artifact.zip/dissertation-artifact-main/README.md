# Dissertation Artifact

This repository contains the following tools:

- **The Stacker**
- **The SMoL Tutor**
- **The SMoL Translator**

Each tool is organized in its own folder.

- **The Stacker** and **The SMoL Translator** can be launched by opening `index.html` in their respective folders.

- **The SMoL Tutor** includes both source code and a pre-built version:
  - To use the pre-built version, open `dist/index.html`.
  - To build from source, navigate to the Tutor's folder and run:
    ```sh
    npm run build
    ```
  - Instructions for hosting the Tutor as a Google Apps Script are available in `docs/host-with-gas/index.md`.
