// `google` is a global variable that Google Apps Script provides
// `tutorialName` and `userID` are URL parameters
//    Note that `tutorialName` is called `tutorial` in URLs. We renamed
//    it in the (Java/Type)Script world to avoid confusing it with
//    the actual tutorial.
import { google } from './Backend';
import { tutorialName, userID } from './GlobalParameters';
// When (in millisecond) was this tutorial open? This can serve as
// a unique identifier for each open of a tutorial.
import { startTime } from './Loop';
import { Request } from './Request';

export type LogDatum = {
    // How many requests you have received?
    index: number;

    // Which (sub-)question the request is about? (See `./tutorials` for questions)
    task: string;
    taskIndex: number;

    // What (in stringified JSON) is the request?
    request: string;
    // When (in millisecond) was the request submitted?
    requestTime: number;

    // What is the response?
    response: string;
    // When (in millisecond) was the response submitted?
    responseTime: number;

    // Is the response correct? (Only applies to some questions)
    correct: null | boolean;
};

const thePostURL = "WHATEVER POST URL THAT WORKS FOR YOU."

export function postLog(logging: LogDatum, whenFail: (logging: LogDatum, msg: any) => void) {
    var xhr = new XMLHttpRequest();
    xhr.open("POST", thePostURL, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify([
        userID,
        startTime,
        tutorialName,
        logging.index,
        logging.task,
        logging.taskIndex,
        logging.request,
        logging.requestTime,
        logging.response,
        logging.responseTime,
        (typeof logging.correct == "boolean") ? logging.correct + "" : ""
    ]));
}


export function googleLog(logging: LogDatum, whenFail: (logging: LogDatum, msg: any) => void) {
    if (google === null) {
        whenFail(logging, "This app is not connected to a Google Script backend.");
    } else {
        google.script.run
            .withSuccessHandler(function (contents: any) {
            })
            .withFailureHandler(function (msg: any) {
                whenFail(logging, msg);
            })
            .log([
                userID,
                startTime,
                tutorialName,
                logging.index,
                logging.task,
                logging.taskIndex,
                logging.request,
                logging.requestTime,
                logging.response,
                logging.responseTime,
                (typeof logging.correct == "boolean") ? logging.correct + "" : ""
            ]);
    }
}
export function noopLog(_logging: LogDatum, _whenFail: (logging: LogDatum, msg: any) => void) {
}
export function consoleLog(logging: LogDatum, _whenFail: (logging: LogDatum, msg: any) => void) {
    console.log(userID)
    console.log(logging);
}

// declare global {
//     interface Window {
//         log: (context: string, request: Request, requestTime: number, response: string, responseTime: number, correct: null | boolean) => void;
//     }
//     var log: (context: string, request: Request, requestTime: number, response: string, responseTime: number, correct: null | boolean) => void;
// }

let loggingIndex = 0;
export const log = (task: string, taskIndex: number, request: Request, requestTime: number, response: string, responseTime: number, correct: null | boolean) => {
    const logging = {
        index: loggingIndex,
        task,
        taskIndex,
        request: JSON.stringify(request),
        requestTime,
        response,
        responseTime,
        correct
    };
    function doIt() {
        googleLog(logging, whenFail);
        // noopLog(logging, whenFail);
        // consoleLog(logging, whenFail);
        // postLog(logging, whenFail)
        function whenFail(logging: LogDatum, msg: any) {
            console.log("Failed to log!");
            console.log("The data is", JSON.stringify(logging));
            console.log("The error message is", msg);
            console.log("The error message is (JSON)", JSON.stringify(msg));
        }
    }
    setTimeout(doIt);
    loggingIndex += 1;
};

(window as any).log = log
