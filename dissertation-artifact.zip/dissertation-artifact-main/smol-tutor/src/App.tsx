import { useState } from 'react';
import './Color.css';
import './App.css';
import { FullHeight, FullWidth, sty, VFlex } from './Layout';
import { Message } from './Message';
import { InputTextLine, InputCheckboxes, InputPickOneOrOther, MessageSelector, InputTextEssay, InputPickOne, InputClickOne } from './MessageWidgets';
import { loop, report, startTime } from './Loop';
import { Choice, Request } from "./Request";
import * as React from 'react';
import { CodeRunnableContext, enableRunning, exportFull, processTutorial, tutorial } from './GlobalParameters';
import { MESSAGE_END_OF_TUTORIAL, PLACEHOLDER_PROGRAM_RESULT } from './StringLiterals';
import { tutorials } from './tutorials';
import { kindOfQuestion } from './TutorialType';
import { parseJSON } from './parseJSON';
import { Markdown } from './Markdown';

// // This function is used to print smol programs into the console of web browser.
// // The printing includes some extra text such that I can test the programs easily.
// // Yeah, this is hacky.
// function printQuizzes() {
//   let testText = "";
//   for (const k in tutorial.questions) {
//     const q = tutorial.questions[k];
//     if ("program" in q) {
//       const { program, answer } = q;
//       testText += `\n(test-expect/smol '(${program}) "${answer}")`;
//       testText += `\n(test-equivalent '(${program}))`;
//     }
//   }
//   for (const k in tutorial.questions) {
//     const q = tutorial.questions[k];
//     if ("again" in q) {
//       const { program, answer } = q.again;
//       testText += `\n(test-expect/smol '(${program}) "${answer}")`;
//       testText += `\n(test-equivalent '(${program}))`;
//     }
//   }
//   for (const k in tutorial.questions) {
//     if (! tutorial.order.includes(k)) {
//       alert(`The question ${k} is not included!`)
//     }
//   }
//   console.log(testText);
//   return;
// }
// printQuizzes();

function printQuestionKinds() {
  let testText = "Tutorial,QuestionName,QuestionKind\n";
  for (const [tn, preTutorial] of Object.entries(tutorials)) {
    const tutorial = processTutorial(preTutorial);
    for (const k of tutorial.order) {
      const q = tutorial.questions[k];
      testText += `${tn},${k},${kindOfQuestion(q)}\n`;
    }
  }
  console.log(testText);
  return;
}
// printQuestionKinds();


// This function is an event-handler that prevents users of the tutorial from
// leaving the page without reaching the point where the tutor has saved their progress.
const onbeforeunload = function (e: Event) {
  e.preventDefault();
  let confirmationMessage = "If you leave this webpage now, your work won't be recorded.";
  return (e as any).returnValue = confirmationMessage; //Gecko + Webkit, Safari, Chrome etc.
};

// The "main" of the GUI
function App() {
  const [codeRunnable, setCodeRunnable] = useState(enableRunning);
  const [continuation, _setContinuation] = useState(() => exportFull ? (setCodeRunnable(true), report(tutorial)) : loop(tutorial, () => setCodeRunnable(true)))
  // warn the visitors when they leave the page
  window.addEventListener("beforeunload", onbeforeunload, { capture: true });
  // the remaining stuff
  let response: null | string;
  let lastId: number;
  let counter: number;
  let reason: "valueChange" | "Other";
  type State = [null | string, number, number, typeof reason];
  let setState: (state: State) => void;
  [[response, lastId, counter, reason], setState] = useState([null, -1, 0, "Other"] as State);
  const result = continuation.next(null);
  // console.log("result", result)
  const [request, messages] = result.value as [Request, (Message | null)[]];
  // console.log(JSON.stringify([request, response, lastId, counter]))
  const onChange = (response: string | null): void => {
    setState([response, lastId, counter + 1, "valueChange"]);
  };
  const validate = validateOfRequest(request);
  const onSubmit = (directResponse?: string) => {
    let localResponse = (typeof directResponse === "string" ? directResponse : response);
    if (typeof localResponse === "string" && validate(localResponse)) {
      setState([null, lastId, counter + 1, "Other"]);
      continuation.next(localResponse);
    }
  };
  const isSelectable = (m: Message) => {
    if (request.kind === "select") {
      const { } = request;
      return m.tags.some(tag => request.tags.includes(tag));
    } else {
      return false;
    }
  };
  const isSelected = (i: number) => {
    if (request.kind === "select") {
      const realResponse: Set<number> = new Set((response === null) ? [] : parseJSON(response));
      return realResponse.has(i);
    } else {
      return false;
    }
  };
  const onSelect = (i: number) => {
    if (request.kind === "select") {
      const realResponse: Set<number> = new Set((response === null) ? [] : parseJSON(response));
      if (!realResponse.has(i)) {
        realResponse.add(i);
      } else {
        realResponse.delete(i);
      }
      setState([JSON.stringify(Array.from(realResponse)), lastId, counter + 1, "valueChange"]);
    } else {
      return false;
    }
  };
  const messageElement = (<MessageSelector
    messages={messages}
    isSelectable={isSelectable}
    isSelected={isSelected}
    onSelect={onSelect}
    endOfSession={request.kind == "end"}
  />);
  const inputElement = inputElementOfRequest(request, onSubmit, response, onChange);
  // Make sure we always scroll to the last element.
  const newId = messages[messages.length - 1]?.id;
  function newMessageArrived(): boolean {
    return newId !== lastId;
  }
  if ((newId !== undefined) && (newMessageArrived() || reason != 'valueChange')) {
    setTimeout(() => {
      lastId = newId;
      document.querySelector("#response-field>*:last-child")?.scrollIntoView({ behavior: "auto" });
      // document.getElementById(htmlIdOfMessageId(newId))?.scrollIntoView({ behavior: "auto" });
    });
  }
  return (
    <CodeRunnableContext.Provider value={codeRunnable}>
      {showApp(messageElement, inputElement)}
    </CodeRunnableContext.Provider>);
}

function inputElementOfRequest(
  request: Request,
  onSubmit: (response?: string) => void,
  response: string | null,
  onChange: (response: string | null) => void
) {
  return Request.case<JSX.Element>(
    request,
    {
      whenEnd: function (): JSX.Element {
        window.removeEventListener("beforeunload", onbeforeunload, { capture: true });
        let txt = MESSAGE_END_OF_TUTORIAL;
        return (
          <div style={{ position: "relative" }}>
            <Markdown src={txt} />
            <span style={{ color: "lightgrey", position: "absolute", bottom: "0", right: "0", fontSize: "xx-small" }}>Start time: {startTime}</span>
          </div>
        );
      },
      whenConfirm: function (text: string): JSX.Element {
        return (<button autoFocus={true} onClick={(_) => onSubmit("")} style={sty(FullWidth, FullHeight)}>{text}</button>);
      },
      whenEssay: function (): JSX.Element {
        return (<InputTextEssay value={response} onChange={onChange} onSubmit={onSubmit} />);
      },
      whenProgramResult: function (): JSX.Element {
        return (<InputTextLine value={response} placeholder={PLACEHOLDER_PROGRAM_RESULT} onChange={onChange} onSubmit={onSubmit} />);
      },
      whenSelect: function (tags: string[]): JSX.Element {
        const realResponse: Set<number> = new Set((typeof response === "string") ? parseJSON(response) : []);
        return (<button onClick={() => onSubmit()} style={sty(FullWidth, FullHeight)}>Submit ({realResponse.size} selected)</button>);
      },
      whenSimpleChooseOne: function (choices: Choice[]): JSX.Element {
        return (<InputClickOne choices={choices} value={response} onChange={onChange} onSubmit={onSubmit} />);
      },
      whenChooseOne: function (choices: Choice[]): JSX.Element {
        return (<InputPickOne choices={choices} value={response} onChange={onChange} onSubmit={onSubmit} />);
      },
      whenChooseOneOrOther: function (choices: Choice[]): JSX.Element {
        return (<InputPickOneOrOther choices={choices} value={response} onChange={onChange} onSubmit={onSubmit} />);
      },
      whenChooseMany: function (choices: Choice[]): JSX.Element {
        return (<InputCheckboxes choices={choices} value={response} onChange={onChange} onSubmit={onSubmit} />);
      }
    }
  );
}

function validateOfRequest(request: Request) {
  const trivialValidate = (response: string) => true;
  const validate = Request.case(
    request,
    {
      whenEnd: function () {
        return trivialValidate;
      },
      whenConfirm: function (text: string): (response: string) => boolean {
        return trivialValidate;
      },
      whenEssay: function (): (response: string) => boolean {
        return trivialValidate;
      },
      whenProgramResult: function (): (response: string) => boolean {
        return trivialValidate;
      },
      whenSelect: function (tags: string[], min: number, max: number): (response: string) => boolean {
        return (response) => {
          const realResponse: Set<number> = new Set((response === "") ? [] : parseJSON(response));
          return min <= realResponse.size && realResponse.size < max;
        };
      },
      whenSimpleChooseOne: function (choices: Choice[]): (response: string) => boolean {
        return trivialValidate;
      },
      whenChooseOne: function (choices: Choice[]): (response: string) => boolean {
        return trivialValidate;
      },
      whenChooseOneOrOther: function (choices: Choice[]): (response: string) => boolean {
        return trivialValidate;
      },
      whenChooseMany: function (choices: Choice[]): (response: string) => boolean {
        return trivialValidate;
      }
    }
  );
  return validate;
}

function showApp(elementOfMessages: JSX.Element, elementOfResponsing: JSX.Element) {
  return (
    <VFlex style={{
      minHeight: "100vh"
    }}>
      {elementOfMessages}
      <div
        id='response-field'
        style={{
          padding: "1ex",
          paddingBottom: "1em",
          borderTop: "1px solid black",
          backgroundColor: "rgb(250,250,250)"
        }}
      >
        {elementOfResponsing}
      </div>
    </VFlex>
  );
}

export default App;
