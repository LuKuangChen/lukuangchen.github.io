export type MaybeAnnotated<X, A> = Annotated<X, A> | Raw<X>;
interface Annotated<X, A> {
    kind: "annotated";
    datum: X;
    annotation: A;
}
interface Raw<X> {
    kind: "raw";
    datum: X;
}

export const MaybeAnnotated = {
    Annotated: function <X, A>(datum: X, annotation: A): MaybeAnnotated<X, A> {
        return { kind: "annotated", datum, annotation };
    },
    Raw: function <X, A>(datum: X): MaybeAnnotated<X, A> {
        return { kind: "raw", datum };
    },
    case: function <O, X, A>(
        target: MaybeAnnotated<X, A>,
        handlers: {
            whenAnnotated: (x: X, a: A) => O,
            whenRaw: (x: X) => O,
        }
    ): O {
        const { whenAnnotated, whenRaw } = handlers;
        switch (target.kind) {
            case "annotated": {
                return whenAnnotated(target.datum, target.annotation);
            }
            case "raw": {
                return whenRaw(target.datum);
            }
        }
    }
};
