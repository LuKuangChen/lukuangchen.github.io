export function parseJSON(json: string): any {
  try {
    return JSON.parse(json);
  } catch (e) {
    console.log(`Failed in parsing a JSON string. The string is: \`${json}\``);
    return null;
  }
}
