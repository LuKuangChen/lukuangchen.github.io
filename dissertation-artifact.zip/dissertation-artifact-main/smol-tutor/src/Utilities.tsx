import { makeUrl } from "./Markdown";
import { Syntax } from "./TutorialType";

export function currentTime() {
    return (new Date()).getTime();
}
(window as any).currentTime = currentTime;

export function randInt(upperBound: number) {
    return Math.floor(upperBound * Math.random());
}

export function shuffle<element>(arr0: element[]) {
    const indexes = [];
    for (let i = 0; i < arr0.length; i++) {
        indexes.push(i);
    }
    const arr1: element[] = [];
    while (indexes.length > 0) {
        const i = randInt(indexes.length);
        arr1.push(arr0[indexes[i]]);
        // remove the element
        indexes.splice(i, 1);
    }
    return arr1;
}

export function download(filename: string, text: string) {
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);

    element.style.display = 'none';
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
}

export function makeRunButton(program: string, syntax: Syntax): string {
    const logCode = `log("", "", "run-in-stacker", currentTime(), "", currentTime(), null)`;
    const buttonCode = `<a class="run-button" target="_blank" href='${makeUrl(syntax, program)}' onclick='${logCode}'>[Run ▶️]</a>`;
    return buttonCode;
}

export function distinct(ss: string[]): string[] {
    return [...new Set(ss)];
}

export const numberRegExp = /(?<![a-zA-Z])[0-9]+(?![a-zA-Z])/g;

export function extractNumbersFromString(str: string): string[] {
    return distinct(Array.from(str.matchAll(numberRegExp), m => m[0]));
}

export function normalizeProgramResult(x: string): string {
    // remove whitespace from the beginning and the end.
    x = x.trim();
    // make all letters lowercase
    x = x.toLowerCase();
    // replace 'error: ...' with 'error'
    x = x.replaceAll(/err.*$/g, "error");

    if (x.endsWith("error")) {
        return [...extractNumbersFromString(x), "error"].join(" ");
    } else {
        return extractNumbersFromString(x).join(" ");
    }
}