import { forwardRef, useState } from 'react';
import { HFlex, VGroupStyle, Rigid, sty, VFlex, widthTakeAll, VFlexStyle } from './Layout';
import { Message, textOfMessage } from './Message';
import { Converter } from 'showdown';
import './MessageWidgets.css';
import { Choice, valueOfChoice } from './Request';
import * as React from 'react';
import { Markdown } from './Markdown';
import { parseJSON } from './parseJSON';
import { allSyntaxes, defaultSecondarySyntax, primarySyntax, exportFull, syntax } from './GlobalParameters';

interface InputTextProps {
  value: string;
  placeholder: string;
  onChange: (datum: string) => void;
  onClick?: () => void;
}

export function InputText(props: InputTextProps) {
  const { value, placeholder, onChange, onClick } = props;
  return (
    <input
      type="text"
      autoComplete={"off"}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      onClick={onClick !== undefined ? (e) => onClick() : undefined}
      placeholder={placeholder}
    />
  );
}

export function ToggleBox(props: { value: boolean, onClick: () => void, children: any; }) {
  const { value, onClick, children } = props;
  return (
    <label>
      <input
        type={"radio"}
        style={{
          marginRight: "1ex",
        }}
        onChange={(_) => onClick()}
        checked={value}
      />
      {children}
    </label>
  );
}


type InputPickerWithOtherProps = {
  choices: Array<Choice>;
  value: string | null;
  onChange: (choice: string | null) => void;
  onSubmit: () => void;
};
export function InputPickerWithOther(props: InputPickerWithOtherProps) {
  const [otherValue, setOtherValue] = useState(null as null | string);
  const { choices, value: rawValue, onChange, onSubmit } = props;
  const { isOther, value }: { isOther: boolean, value: string | null; } = (rawValue === null) ? { isOther: true, value: null } : JSON.parse(rawValue);
  const elementOfKnownChoice = (c: Choice, i: number) => {
    const [display, meaning] = (typeof c === "string") ? [c, c] : c;
    return (
      <div
        key={i}
      >
        <ToggleBox value={meaning === value} onClick={() => {
          if (c === value) {
            onChange(null);
          } else {
            onChange(JSON.stringify({ isOther: false, value: meaning }));
          }
        }}>
          <Markdown src={display}></Markdown>
        </ToggleBox>
      </div>
    );
  };
  const elementOfUnknownChoice = (c: string | null, i: number) => {
    const onClick = () => {
      if (c === value) {
        onChange(null);
      } else {
        // why not use otherValue?
        onChange(JSON.stringify({ isOther: true, value: c }));
      }
    };
    return (
      <div
        key={i}
      >
        <ToggleBox value={isOther} onClick={onClick}>
          <InputText
            value={c || ""}
            placeholder="Other"
            onChange={(datum: string) => {
              setOtherValue(datum);
              onChange(JSON.stringify({ isOther: true, value: datum }));
            }}
            onClick={onClick} />
        </ToggleBox>
      </div>
    );
  };
  return (
    <form onSubmit={(e) => {
      e.preventDefault();
      if ([...choices.map(valueOfChoice), otherValue].indexOf(value) >= 0) {
        onSubmit();
      }
    }} style={sty(VGroupStyle, widthTakeAll)}>
      <VFlex>
        {choices.map(elementOfKnownChoice)}
        {elementOfUnknownChoice(otherValue, choices.length)}
      </VFlex>
      <button type="submit">↟ Send ↟</button>
    </form>
  );
}

type InputPickerWithoutOtherProps = {
  choices: Array<Choice>;
  value: string | null;
  onChange: (choice: string | null) => void;
  onSubmit: () => void;
};
export function InputPickerWithoutOther(props: InputPickerWithoutOtherProps) {
  const { choices, value, onChange, onSubmit } = props;
  const elementOfKnownChoice = (c: Choice, i: number) => {
    const [display, meaning] = (typeof c === "string") ? [c, c] : c;
    return (
      <div
        key={i}
      >
        <ToggleBox value={meaning === value} onClick={() => {
          if (c === value) {
            onChange(null);
          } else {
            onChange(meaning);
          }
        }}>
          <Markdown src={display}></Markdown>
        </ToggleBox>
      </div>
    );
  };
  return (
    <form onSubmit={(e) => {
      e.preventDefault();
      if ([...choices.map(valueOfChoice)].indexOf(value as string) >= 0) {
        onSubmit();
      }
    }} style={sty(VGroupStyle, widthTakeAll)}>
      <VFlex>
        {choices.map(elementOfKnownChoice)}
      </VFlex>
      <button type="submit">↟ Send ↟</button>
    </form>
  );
}



type InputPickOneOrOtherProps = {
  choices: Array<Choice>;
  value: string | null;
  onChange: (choice: string | null) => void;
  onSubmit: () => void;
};
export function InputPickOneOrOther(props: InputPickOneOrOtherProps) {
  return InputPickerWithOther(Object.assign({}, props));
}


type InputPickOneProps = {
  choices: Array<Choice>;
  value: string | null;
  onChange: (choice: string | null) => void;
  onSubmit: (response?: string) => void;
};
export function InputPickOne(props: InputPickOneProps) {
  return InputPickerWithoutOther(Object.assign({}, props));
}


export function InputClickOne(props: InputPickOneProps) {
  const { choices, onChange, onSubmit } = props;
  return (
    <menu>
      {choices.map((c) => {
        const [display, meaning] = (typeof c === "string") ? [c, c] : c;
        return (
          <button onClick={() => { onSubmit(meaning); }}>
            {display}
          </button>
        );
      })}
    </menu>
  );
}

export function CheckedBox(props: { value: boolean; onChange: (e: null) => void; children: any; }) {
  const { value, onChange, children } = props;
  return (
    <div style={{
      display: "flex",
      flexDirection: "row",
      gap: "1ex"
    }} onClick={(_) => onChange(null)}>{value ? "✅" : "🔲"} {children}</div>
  );
}

export function InputCheckboxes(props: { choices: Choice[]; value: string | null; onChange: (datum: string) => void; onSubmit: (response: string) => void; }) {
  let { choices, value, onChange, onSubmit } = props;
  if (typeof value !== "string") {
    value = JSON.stringify(choices.map((_) => false));
  }
  let internalValue = parseJSON(value);
  return (
    <form onSubmit={(e) => {
      e.preventDefault();
      onSubmit(JSON.stringify(internalValue));
    }} style={sty(VGroupStyle, widthTakeAll)}>
      <VFlex>
        {choices.map((c, i) => {
          const [display, meaning] = (typeof c === "string") ? [c, c] : c;
          return (
            <label key={i}>
              <CheckedBox
                value={internalValue[i]}
                onChange={(e) => {
                  internalValue[i] = !internalValue[i];
                  onChange(JSON.stringify(internalValue));
                }}
              >
                <Markdown src={display} />
              </CheckedBox>
            </label>
          );
        })}
      </VFlex>
      <button type="submit">↟ Send ↟</button>
    </form>
  );
}

interface InputTextLineProps {
  value: string | null;
  placeholder: string;
  onSubmit: () => void;
  onChange: (v: string) => void;
  // checker?: (v: string) => string[];
};

export function InputTextLine(props: InputTextLineProps) {
  const { value, placeholder, onChange, onSubmit } = props;
  return (
    <VFlex>
      <input
        type="text"
        name="user-response"
        id="user-reponse"
        autoComplete={"off"}
        value={value || ""}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Enter") {
            onSubmit();
          }
        }} />
      <button onClick={() => {
        onSubmit();
      }}>↟ Send ↟</button>
    </VFlex>
  );
}

export function InputTextEssay(props: { onSubmit: (value?: string) => void; onChange: (v: string) => void; checker?: (v: string) => string[]; value: string | null; }) {
  const { value, onChange, onSubmit } = props;
  return (
    <Rigid>
      <VFlex>
        <HFlex>
          <textarea
            style={sty({
              marginRight: "1ex",
              resize: "none",
            })}
            rows={4}
            name="user-response"
            id="user-reponse"
            autoComplete={"off"}
            value={value || ""}
            onChange={(e) => onChange(e.target.value)} />
        </HFlex>
        <button onClick={() => {
          onSubmit(value || "");
        }}>↟ Send ↟</button>
      </VFlex>
    </Rigid>
  );
}

const MessageBreaker = (props: {}) => {
  return (
    <hr />
  );
};


function syntaxSwitch(syntaxPool: syntax[], chosenSyntax: syntax, choose: (s: syntax) => void) {
  if (exportFull) {
    return <></>;
  } else {
    // console.log("clicked")
    return (
      <span className='syntax-switcher' >
        <button onClick={(e) => {
          e.preventDefault();
          if (syntaxPool.length > 1) {
            let newSyntax: syntax = chosenSyntax;
            do {
              newSyntax = syntaxPool[Math.floor(Math.random() * syntaxPool.length)];
            } while (newSyntax == chosenSyntax);
            choose(newSyntax);
          }
        }}>{primarySyntax} | 🎲</button>
      </span>
    );
  }
}


// function syntaxSwitch(syntaxPool: syntax[], chosenSyntax: string, choose: (s: syntax) => void) {
//   function chooser(name: syntax) {
//     return (
//       <li>
//         <label>
//           <input type='radio' name='syntax' value={name} checked={name == chosenSyntax} onClick={_ => choose(name)} /><span>{name}</span>
//         </label>
//       </li>
//     );
//   }
//   if (exportFull) {
//     return <></>
//   } else {
//     return (
//       <span className='syntax-switcher'>
//         <span>{"Syntax: "}</span>
//         <menu>
//           {
//             syntaxPool.map((s) => {
//               return chooser(s)
//             })
//           }
//           {/* {chooser("Lispy")}
//           {chooser("JavaScript")}
//           {chooser("Python")}
//           {chooser("Scala 3")}
//           {chooser("Pseudo")} */}
//         </menu>
//       </span>
//     );
//   }
// }

const MessageBox = forwardRef((props: { message: Message; }, ref: React.LegacyRef<HTMLDivElement>) => {
  const { message } = props;
  const syntaxPoolSet = new Set(allSyntaxes);
  syntaxPoolSet.delete(primarySyntax);
  const syntaxPool = [...syntaxPoolSet];
  const [syntax, setSyntax] = useState(
    defaultSecondarySyntax || syntaxPool[Math.floor(Math.random() * syntaxPool.length)]
  );
  const messageText = textOfMessage(message);
  let secondarySyntax = (message.sender == "sys" && !message.disableTranslation) ? syntax : undefined;
  const e = (
    <div
      id={htmlIdOfMessageId(message.id)}
      ref={ref}
      style={{ position: "relative" }}
      className={`Message ${message.sender} ${message.emotion}`}>
      <span className='annotation' style={{ position: "absolute", top: "1ex", right: "1ex", fontSize: "small" }}>{message.id}</span>
      {(secondarySyntax && messageText.includes("```")) ? syntaxSwitch(syntaxPool, syntax, setSyntax) : <></>}
      <Markdown secondarySyntax={secondarySyntax} src={messageText} />
    </div>
  );
  return e;
});

const SelectableMessageBox = forwardRef((props: { message: Message; isSelected: boolean; onClick: () => void; }, ref: React.LegacyRef<HTMLDivElement>) => {
  const { message, isSelected: isSelected, onClick } = props;
  const syntaxPoolSet = new Set(allSyntaxes);
  syntaxPoolSet.delete(primarySyntax);
  const syntaxPool = [...syntaxPoolSet];
  const [syntax, setSyntax] = useState(
    defaultSecondarySyntax || syntaxPool[Math.floor(Math.random() * syntaxPool.length)]
  );
  const messageText = textOfMessage(message);
  let secondarySyntax = (message.sender == "sys" && !message.disableTranslation) ? syntax : undefined;
  const e = (
    <div
      id={`message${message.id}`}
      onClick={onClick && ((_) => onClick())}
      ref={ref}
      style={{ position: "relative" }}
      className={`Message selectable ${message.sender} ${message.emotion} ${isSelected ? "selected" : ""}`}>
      <span className='annotation' style={{ position: "absolute", top: "1ex", right: "1ex", fontSize: "small" }}>{message.id}</span>
      {(secondarySyntax) ? syntaxSwitch(syntaxPool, syntax, setSyntax) : <></>}
      <Markdown secondarySyntax={secondarySyntax} src={messageText} />
    </div>
  );
  return e;
});


export function htmlIdOfMessageId(id: number): string {
  return `message${id}`;
}



export function htmlOfMarkdownString(s: string) {
  // return s;
  const converter = new Converter({ "tasklists": true });
  const htmlText = converter.makeHtml(s);
  return htmlText;
}

function messageGroupsOfMessages(messages: (Message | null)[]): (null | Message[])[] {
  const messageGroups: (Message[] | null)[] = [];
  let currentGroup: (Message[]) | null = null;
  for (const m of messages) {
    if (m === null) {
      if (currentGroup !== null) {
        if (messageGroups.length > 0) {
          messageGroups.push(null);
        }
        messageGroups.push(currentGroup);
        currentGroup = null;
      }
    } else {
      if (currentGroup === null) {
        currentGroup = [];
      }
      currentGroup.push(m);
    }
  }
  if (currentGroup !== null) {
    if (messageGroups.length > 0) {
      messageGroups.push(null);
    }
    messageGroups.push(currentGroup);
    currentGroup = null;
  }
  return messageGroups;
}


type MessageSelectorProps = {
  messages: (Message | null)[];
  isSelectable: (m: Message) => boolean;
  isSelected: (id: number) => boolean;
  onSelect: (id: number) => void;
  endOfSession: boolean;
};
export function MessageSelector(props: MessageSelectorProps) {
  const { messages, isSelectable: filter, isSelected, onSelect, endOfSession } = props;
  return (
    <div
      style={sty(VFlexStyle, {
        padding: "1ex",
      })}
      id="dialog"
      className={(!endOfSession) ? "not-ended" : "ended"}>
      {messageGroupsOfMessages(messages).map((mg, i) => {
        if (mg === null) {
          return (
            <MessageBreaker key={i}></MessageBreaker>
          );
        } else {
          return (
            <form key={i} className="message-group">
              {
                mg.map((m, i) => {
                  if (filter(m)) {
                    return (<SelectableMessageBox key={i} message={m} isSelected={isSelected(m.id)} onClick={() => onSelect(m.id)} />);
                  } else {
                    return (<MessageBox key={i} message={m} />);
                  }
                })
              }
            </form>
          );
        }
      })}
    </div>
  );
}
