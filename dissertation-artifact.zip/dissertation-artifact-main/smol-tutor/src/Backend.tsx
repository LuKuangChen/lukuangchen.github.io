import { TutorialName } from "./TutorialType";

export const google: any = window["google" as any] as any || null;

export async function getCompletionStatus(userID: string): Promise<Record<TutorialName, boolean>> {
    return new Promise((resume) => {
        if (google !== null) {
            google.script.run
                .withSuccessHandler(function (contents: any) {
                    resume(contents);
                })
                .withFailureHandler(function (msg: any) {
                    resume({} as any);
                })
                .getCompletionStatus(userID);
        } else {
            resume({} as any)
        }
    })
}