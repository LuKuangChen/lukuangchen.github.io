import React, { forwardRef } from 'react';

type Style = React.HTMLAttributes<HTMLElement>["style"]

const Container: React.HTMLAttributes<HTMLElement>["style"] = {
    boxSizing: "border-box",
    display: "flex",
    overflow: "auto",
    flexGrow: 1,
}

export const sty = (...styles: Style[]): Style => {
    return Object.assign({}, Container, ...styles)
}

export const FullWidth: Style = sty({
    width: "100%"
})
export const FullHeight: Style = sty({
    height: "100%"
})

export const widthTakeAll: Style = {
    width: "100%"
}

type ContainerProps = {
    children: React.ReactNode;
    style?: React.HTMLAttributes<HTMLElement>["style"];
} & React.HTMLAttributes<HTMLDivElement>;
export function Fullscreen(props: ContainerProps) {
    const { children, style } = props;
    const myStyle: ContainerProps["style"] = {
        width: "100vw",
        height: "100vh",
    };
    const realStyle = Object.assign({}, Container, myStyle, style)
    return (
        <div style={realStyle}>
            {children}
        </div>
    );
}

export const VFlexStyle = Object.assign({}, Container,  {
    flexDirection: "column",
    width: "100%",
    height: "100%"
})
export function VFlex(props: ContainerProps) {
    const { children, style } = props;
    const myStyle: ContainerProps["style"] = {
        flexDirection: "column",
        width: "100%",
        height: "100%"
    };
    const realStyle = Object.assign({}, Container, myStyle, style)
    return (
        <div style={realStyle}>
            {children}
        </div>
    );
}


export const HFlexStyle = Object.assign({}, Container,  {
    flexDirection: "row",
    width: "100%",
    height: "100%"
})
export function HFlex(props: ContainerProps) {
    const { children, style } = props;
    const myStyle: ContainerProps["style"] = {
        width: "100%",
        height: "100%",
        flexDirection: "row",
    };
    const realStyle = Object.assign({}, Container, myStyle, style)
    return (
        <div style={realStyle}>
            {children}
        </div>
    );
}

export const VGroupStyle = Object.assign({}, Container,  {
    flexDirection: "column",
    overflow: "unset",
    flexGrow: 0,
})
export function VGroup(props: ContainerProps) {
    const { children, style } = props;
    // const realStyle = {}
    const myStyle: ContainerProps["style"] = {
        flexDirection: "column",
        overflow: "unset",
        flexGrow: 0,
    };
    const realStyle = Object.assign({}, Container, myStyle, style)
    return (
        <div style={realStyle} className="VGroup">
            {children}
        </div>
    );
}


export const HGroupStyle = Object.assign({}, Container,  {
    flexDirection: "row",
    overflow: "unset",
    flexGrow: 0,
})
export function HGroup(props: ContainerProps) {
    const { children, style } = props;
    const myStyle: ContainerProps["style"] = {
        flexDirection: "row",
        overflow: "unset",
        flexGrow: 0,
    };
    const realStyle = Object.assign({}, Container, myStyle, style)
    return (
        <div style={realStyle}>
            {children}
        </div>
    );
}

export function Blank(props: { style?: ContainerProps["style"]}) {
    const { style } = props;
    const myStyle: ContainerProps["style"] = {
        flexGrow: 1,
    };
    const realStyle = Object.assign({}, myStyle, style)
    return (
        <div style={realStyle}>
        </div>
    );
}

export function Rigid(props: ContainerProps) {
    const { children, style } = props;
    const myStyle: ContainerProps["style"] = {
        flexGrow: 0,
    };
    const realStyle = Object.assign({}, Container, myStyle, style)
    return (
        <div style={realStyle}>
            {children}
        </div>
    );
}


export function Center(props: ContainerProps) {
    const { children, style, ...rest } = props;
    const myStyle: ContainerProps["style"] = {
        display: "flex",
        alignItems: "center",
        justifyContent: "center"
    };
    const realStyle = Object.assign({}, Container, myStyle, style)
    return (
        <div {...rest} style={realStyle}>
            {children}
        </div>
    );
}


export const Ref = forwardRef((props: ContainerProps, ref: React.LegacyRef<HTMLDivElement>) => {
    const { children, style } = props;
    const myStyle: ContainerProps["style"] = {
        display: "contents"
    };
    const realStyle = Object.assign(myStyle, style)
    return (
        <div style={realStyle} ref={ref}>
            {children}
        </div>
    );
})
