import { Choice } from "./Request";

export type Syntax = "Lispy" | "JavaScript" | "Python" | "Scala 3" | "Pseudo";

export type TutorialName = "def1" | "def2" | "def3" | "post1" | "vectors1" | "vectors2" | "vectors3" | "post2" | "mutvars1" | "mutvars2" | "post3" | "refactor" | "lambda1" | "lambda2" | "lambda3" | "post4" | "mini";

export type PreTutorial = {
    misconceptions: string[],
    order: (string | string[])[],
    questions: Record<string, Question>;
};

export type Tutorial = {
    order: string[],
    questions: Record<string, Question>;
};
export const Question = {
    case: function <X>(
        quiz: Question,
        handlers: {
            whenReflection: (datum: Reflection) => X,
            whenGuessOutput: (datum: GuessOutput) => X,
            whenConfirm: (datum: Confirm) => X,
            whenLabelling: (datum: Labelling) => X,
            whenPickOne: (datum: PickOne) => X,
            whenPickMany: (datum: PickMany) => X,
        },
    ): X {
        // console.log("Question.case is processing", JSON.stringify(quiz));
        const {
            whenReflection,
            whenGuessOutput,
            whenConfirm,
            whenLabelling,
            whenPickOne: whenPictOne,
            whenPickMany: whenPictMany,
        } = handlers;

        if ("checkboxes" in quiz) {
            // console.log("I am in checkboxes");
            return whenPictMany(quiz);
        } else if ("confirm" in quiz) {
            // console.log("I am in confirm");
            return whenConfirm(quiz);
        } else if ("emphasize" in quiz) {
            // console.log("I am in emphasize");
            return whenConfirm(quiz);
        } else if ("select_and_comment" in quiz) {
            // console.log("I am in expected_label");
            return whenLabelling(quiz);
        } else if (!("answer" in quiz)) {
            // console.log("I am in whenReflection");
            return whenReflection(quiz);
        } else if ("distractors" in quiz) {
            // console.log("I am in whenPictOne");
            return whenPictOne(quiz);
        } else {
            // console.log("I am in whenGuessOutput");
            return whenGuessOutput(quiz);
        }
    }
};

export type Question = Reflection | GuessOutput | Confirm | Labelling | PickOne | PickMany;
type Reflection = { prompt: string, feedback?: string; };
type GuessOutput = {
    program: string,
    answer: string,
    feedback: string,
    incompatible?: Record<Syntax, { reason: string; }>;
    misconceptions?: Record<string, { misconception: string; feedback?: string; feedback_stacker?: string; }>,
    again: {
        program: string,
        answer: string;
    };
};
type Confirm = { confirm: string; } | { emphasize: string; };
type Labelling = { select_and_comment: string; };
type PickOne = {
    prompt?: string,
    program: string,
    distractors: Choice[],
    answer: Choice,
    feedback: string;
};
type PickMany = {
    prompt: string;
    checkboxes: [boolean, string][];
    feedback: string;
};

type QKind =
    | "other text"
    | "goal sentences"
    | "guessOutput"
    | "reflection"
    | "select-program-and-comment"
    | "select-one"
    | "select-many"
    | "stacker exercise";

export const kindOfQuestion = (q: Question) => {
    const ret = (k: QKind) => {
        return (_: any) => {
            return k;
        };
    };
    return Question.case(q, {
        whenConfirm: (q): QKind => {
            if ("confirm" in q) {
                if (q.confirm.includes("DrRacket")) {
                    return "stacker exercise";
                } else {
                    return "other text";
                }
            } else {
                return "goal sentences";
            }
        },
        whenReflection: ret("reflection"),
        whenGuessOutput: ret("guessOutput"),
        whenLabelling: ret("select-program-and-comment"),
        whenPickOne: ret("select-one"),
        whenPickMany: ret("select-many"),
    });
};