import { translators } from './ImportTranslator';
import { DEFAULT_PROGRAM_QUESTION_TEXT } from './StringLiterals';
import { PreTutorial, Question, Syntax, TutorialName, Tutorial } from './TutorialType';
import { shuffle } from './Utilities';
import { tutorials } from './tutorials';
import { makeUrl } from './Markdown';
import { createContext } from 'react';
import { getCompletionStatus } from './Backend';

// You can comment out unwanted syntaxes.
export const allSyntaxes: Array<Syntax> = [
    "Lispy",
    "JavaScript",
    "Python",
    "Scala 3",
    "Pseudo"
];
// You can comment out unwanted tutorials.
// export const allTutorials: TutorialName | Array<TutorialName> = "mini"
export const allTutorials: TutorialName | Array<TutorialName> = [
    "def1",
    "def2",
    "def3",
    "post1",
    "vectors1",
    "vectors2",
    "vectors3",
    "post2",
    "mutvars1",
    "mutvars2",
    "post3",
    "refactor",
    "lambda1",
    "lambda2",
    "lambda3",
    "post4",
];

// You can choose if you want to load progress from the backend.
const loadingProgress = false;

/*
Programs are always displayed in two syntaxes.
We call the syntax for the left-hand-side version as **PrimarySyntax**.
We call the syntax for the right-hand-side version as **SecondarySyntax**.

The PrimarySyntax must stay the same within a tutorial.
The SecondarySyntax can be changed by clicking the dice button.

Instructor users can configure the PrimarySyntax by setting the following two global variables:
*/

const defaultPrimarySyntax: Syntax = "Lispy";
const defaultPrimarySyntaxEnforced: boolean = false;

/*
If defaultPrimarySyntaxEnforced is true, the defaultPrimarySyntax will be the PrimarySyntax.

Otherwise, a student user will see a dropdown before start working on a tutorial.
The dropdown allow student users to choose another syntax as the PrimarySyntax.
*/


/*
Instructor uses can configure the Secondary by setting the following global variables:
*/
export const defaultSecondarySyntax: Syntax | null = null;
/*
If the defaultSecondarySyntax is syntax, the SecondarySyntax is default to the syntax for each
question.

Otherwise, the SecondarySyntax is chosen at random.
*/

// Let the student user to pick a primarySyntax, using the following program as an illustration
// for all sorts of syntaxes.
const sampleProgram = `
(defvar x 2)
(deffun (f n)
  (+ x 3))
(defvar v (mvec 56 78))
(set! x 4)
(vec-set! v 0 (f 1))
x
v
`;
async function askForPrimarySyntax(): Promise<Syntax> {
    let maybeDialog = document.querySelector("dialog");
    let maybeForm = document.querySelector("form");
    let maybeSelect = document.querySelector("select");
    let maybeOutput = document.querySelector("output");
    let maybeSpan = document.querySelector("span.syntaxName");
    if (maybeDialog && maybeForm && maybeSelect && maybeOutput && maybeSpan) {
        let dialog = maybeDialog;
        let form = maybeForm;
        let select = maybeSelect;
        let output = maybeOutput;
        let span = maybeSpan;
        span.innerHTML = defaultPrimarySyntax;
        output.value = translators.Program[defaultPrimarySyntax](true, sampleProgram);
        // add options
        for (const s of allSyntaxes) {
            let e = document.createElement("option");
            e.innerHTML = s;
            e.value = s;
            if (s == defaultPrimarySyntax) {
                e.selected = true;
            }
            select.appendChild(e);
        }
        select.onchange = (_) => {
            let value = select.value as Syntax;
            if (allSyntaxes.includes(value)) {
                span.innerHTML = value;
                output.value = translators.Program[value](true, sampleProgram);
            }
        };
        // present dialog
        dialog.showModal();
        return new Promise((resolve) => {
            dialog.onclose = (ev) => {
                let value = select.value as Syntax;
                console.log("value: ", value);
                resolve(allSyntaxes.includes(value) ? value : "Lispy");
            };
        });
    } else {
        return "Pseudo";
    }
}
export const primarySyntax = defaultPrimarySyntaxEnforced
    ? defaultPrimarySyntax
    : await askForPrimarySyntax();

// The tutor presents stacker-related questions and run buttons
// only if the following boolean is true.
export const presentingStacker: boolean = true;

// URL parameters
function getUrlParams() {
    if (location.search != "") {
        return Object.fromEntries(new URLSearchParams(location.search));
    } else {
        let fromGAS = document.querySelector("#url-parameters")?.innerHTML;
        if (fromGAS) {
            return JSON.parse(fromGAS);
        } else {
            return {};
        }
    }
}
export const urlParams = getUrlParams();

// {
//     let span = document.createElement("span");
//     span.innerText = [
//         "debug: ",
//         JSON.stringify(urlParams),
//         document.querySelector("#url-parameters"),
//         document.querySelector("#url-parameters")?.innerHTML,
//     ].join(";");
//     document.querySelector("body")?.appendChild(span);
// }

export const userID: string = urlParams["userEmail"] || "AnonymousUser";

async function getTutorialName(): Promise<TutorialName> {
    if (typeof allTutorials == "string") {
        return allTutorials;
    }
    let tutorial = urlParams["tutorial"] || window["tutorial" as any] as any;
    if (allTutorials.includes(tutorial)) {
        return tutorial;
    }
    let dialog: HTMLDialogElement | null = document.querySelector("dialog#tutorial-chooser");
    let p: Promise<TutorialName> = new Promise((resume) => {
        dialog?.addEventListener("close", (_) => {
            let val = dialog?.returnValue;
            if (val && allTutorials.includes(val as any)) {
                resume(val as any);
            } else {
                resume(allTutorials[0]);
            }
        });
    });
    let toc = document.querySelector("form#tutorial-chooser table");
    for (const t of allTutorials) {
        let tr = document.createElement("tr");
        tr.innerHTML = "<td>" +
            `<button value="${t}">${t}</button>` +
            `</td><td class="display-progress">` +
            `<span id="${t}-status">🤷 Loading</span>` +
            `</td>`;
        toc?.appendChild(tr);
    }
    dialog?.showModal();
    if (!loadingProgress) {
        for (const e of Array.from(document.querySelectorAll(".display-progress"))) {
            ((e as any) as HTMLElement).style.display = "none";
        }
    }
    if (loadingProgress) {
        setTimeout(async () => {
            let completionStatus = await getCompletionStatus(userID);
            for (const t of allTutorials) {
                let st = document.querySelector(`#${t}-status`);
                if (st) {
                    st.innerHTML = completionStatus[t] ? "✅ Finished" : "❌ Not finished";
                }
            }
        });
    }
    return p;
}
export const tutorialName: TutorialName = await getTutorialName();
export const tutorial = processTutorial(tutorials[tutorialName]);

// When true, the tutor export the whole tutorial rather than asking all questions one by one
export const exportFull: boolean = false;
// Whether the run button is presented starting from the very beginning.
// Usually, run buttons are presented only when students reach the end of each tutorial.
export let enableRunning: boolean = false;
export const CodeRunnableContext = createContext(enableRunning);


// A function that control whether we ask for an explanation.
let timeAsked = 0;
export function askingExplanation(taskName: string, isCorrect: boolean): boolean {
    // ask only if the question is neither a post-test nor warm-up and we have not
    // asked for more than 2 times. Even than, we do it randomly, an incorrect answer
    // is more likely to trigger an explanation request.
    if (timeAsked < 2
        && !taskName.startsWith("post_")
        && !taskName.startsWith("warmup_")
        && ((isCorrect && Math.random() <= 0.1)
            || (!isCorrect && Math.random() <= 0.2))) {
        timeAsked += 1;
        return true;
    }
    return false;
}

export function processTutorial(tutorial: PreTutorial): Tutorial {
    // 1. Randomly order questions
    // 2. Generate question prompt for some MCQs
    // 3. Tag some interpreting questions to ask for explanations.
    const { order, questions } = tutorial;
    let newOrder = order.flatMap(
        (taskGroup) => {
            if (typeof taskGroup === "string") {
                return [taskGroup];
            } else {
                return shuffle(taskGroup);
            }
        }
    );
    if (newOrder.length != Object.keys(questions).length) {
        alert("Some questions are not presented or presented multiple times.");
        const s1 = new Set(newOrder);
        const s2 = new Set(Object.keys(questions));
        const s1Ds2 = [...s1].filter((x) => !s2.has(x));
        const s2Ds1 = [...s2].filter((x) => !s1.has(x));
        console.log(s1Ds2);
        console.log(s2Ds1);
    }
    if (!presentingStacker) {
        newOrder = newOrder.filter((q) => !q.startsWith("keyframe"));
    }
    const newQuestions: Record<string, Question> = Object.fromEntries(
        Object.entries(questions).map(([n, q]) => {
            let newQ;
            if ("distractors" in q && "program" in q && !("prompt" in q)) {
                const { program, distractors, answer, feedback } = q;
                newQ = {
                    prompt: DEFAULT_PROGRAM_QUESTION_TEXT + '\n\n```\n' + program + '\n```',
                    distractors, answer, feedback
                };
            } else {
                newQ = q;
            }
            return [n, newQ];
        })
    );
    return {
        order: newOrder, questions: newQuestions
    };
}
export { Syntax as syntax };

