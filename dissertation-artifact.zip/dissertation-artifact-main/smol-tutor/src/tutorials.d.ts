import { PreTutorial } from "./TutorialType";
export const tutorials: Record<string, PreTutorial>;