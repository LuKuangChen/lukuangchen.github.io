import { Message, sysSays, usrSays, Emotion } from './Message';
import { Choice, Request, valueOfChoice } from './Request';
import { CONFIRM_GENERAL, DEFAULT_PROGRAM_QUESTION_TEXT, CONFIRM_READY_TO_ANSWER, FEEDBACK_CORRECT_PO_ANSWER, FEEDBACK_CORRECT_C_ANSWER, CONFIRM_HAVING_READ_EXPLANATION, FEEDBACK_WRONG_ANSWER_TO_ISO_QUESTION_FIRST, FEEDBACK_WRONG_ANSWER_TO_ISO_QUESTION_REST, CONFIRM_READY_FOR_NEXT_QUESTION, ASK_FOR_FEEDBACK_ON_GOAL_SENTENCES, WHEN_NO_FEEDBACK_ON_GOAL_SENTENCES, THANKS_FOR_FEEDBACK, PROMPT_EXPLANATION, CONFIRM_HAVING_READ_EXPLANATION_POS, CONFIRM_HAVING_READ_EXPLANATION_NEG, ASK_FOR_FEEDBACK_ON_EXPLANATION } from './StringLiterals';
import { Tutorial } from './TutorialType';
import { parseJSON } from './parseJSON';
import { log } from './Log';
import { currentTime, distinct, extractNumbersFromString, normalizeProgramResult, numberRegExp, shuffle } from './Utilities';
import { askingExplanation, primarySyntax, presentingStacker } from './GlobalParameters';
import { makeUrl } from './Markdown';

export const startTime = currentTime();

// yield [Request, (Message | null)[]]
// return void
// accept string | null
export function* report(tutorial: Tutorial): Iterator<[Request, (Message | null)[]], void, string | null> {
  const messages: (Message | null)[] = [];
  function weSay(s: string, e: Emotion = "neutral") {
    messages.push(sysSays(s, e));
    return;
  }
  function postProgram(prompt: string, program: string) {
    weSay(prompt + (program ? "\n\n```\n" + program + "```\n" : ""), "neutral");
    return;
  }
  function makeBreak() {
    messages.push(null);
  }
  const { order, questions } = tutorial;
  let request: Request;
  let userInput: string | null;
  let taskIndex = -1;
  for (let quizName of order) {
    taskIndex += 1;
    const quiz = questions[quizName];
    if ("checkboxes" in quiz) {
      // PickMany
      const { prompt, checkboxes, feedback } = quiz;
      weSay(prompt);
      weSay(checkboxes.
        map(([truth, choice]) => {
          return `${truth ? "✅" : "🔲"} ${choice}  `;
        }).
        join('\n'));
      weSay("[In addition to pointing out which should be selected and which should not, we also say:]\n\n" + feedback);
    } else if ("confirm" in quiz) {
      const { confirm } = quiz;
      weSay(confirm);
    } else if ("emphasize" in quiz) {
      const { emphasize } = quiz;
      weSay(emphasize, "emphasizing");
    } else if ("select_and_comment" in quiz) {
      continue;
      // Labelling
      // const { select_and_comment } = quiz;
      // weSay(select_and_comment);
    } else if (!("answer" in quiz)) {
      // Reflection
      const { prompt, feedback } = quiz;
      weSay(prompt);
      if (typeof feedback === "string") {
        weSay(feedback);
      }
    } else if ("distractors" in quiz) {
      // PickOne
      let { prompt, program, distractors, answer, feedback } = quiz;
      prompt = prompt || DEFAULT_PROGRAM_QUESTION_TEXT;
      postProgram(prompt, program);
      const choiceTable: [Choice, number, string][] = [answer, ...distractors].
        map((c, i) => {
          return [c, i] as [Choice, number];
        }).
        sort(([choice1, _i1], [choice2, _i2]) => {
          const v1 = valueOfChoice(choice1);
          const v2 = valueOfChoice(choice2);
          return v1.localeCompare(v2);
        }).
        map(([c, i], j) => {
          const letter = "ABCDEFGHIJKLMN"[j];
          return [c, i, letter];
        });
      weSay(
        "[All choices:]\n\n" +
        "<ol type='A'>" +
        choiceTable.map(([s, _i, l]) => `<li><code>${s}</code></li>`).join('\n') +
        "</ol>"
      );
      let processedFeedback = feedback;
      for (const [s, i, l] of choiceTable) {
        processedFeedback = processedFeedback.replaceAll(`%${i}%`, `**${l}**`);
      }
      processedFeedback = processedFeedback.replaceAll(/%(\d+),(\d+)%/g, (match, p1: string, p2: string) => {
        const i1 = parseInt(p1);
        const i2 = parseInt(p2);
        const j1 = choiceTable.findIndex(([s, i, l]) => i == i1);
        const j2 = choiceTable.findIndex(([s, i, l]) => i == i2);
        const [_s1, _i1, l1] = choiceTable[j1];
        const [_s2, _i2, l2] = choiceTable[j2];
        if (j1 <= j2) {
          return `**${l1}** and **${l2}**`;
        } else {
          return `**${l2}** and **${l1}**`;
        }
      });
      weSay(`${processedFeedback}`);
      // weSay(`If the student picks the correct answer (\`${answer}\`), we say:`);
      // weSay(FEEDBACK_CORRECT_ANSWER + `\n\n${processedFeedback}`);
      // weSay(`If the student picked anything other than the correct answer, we say:`);
      // weSay(`The answer is \`${answer}\`.\n\n${processedFeedback}`);
    } else {
      // GuessOutput
      const { program, answer, feedback: genericFeedback, misconceptions, again } = quiz;
      const prompt = DEFAULT_PROGRAM_QUESTION_TEXT;
      postProgram(prompt, program);
      let literals = extractNumbersFromString(program);
      let choices = [...Object.keys(misconceptions || {})];
      choices = addDistractors(answer, choices, literals);
      choices = choices.sort((c1, c2) => {
        const n = c1.length - c2.length;
        return n || c1.localeCompare(c2);
      });
      weSay(`The choices are:\n\n${[...choices, "other"].map((c) => `- \`${c}\``).join('\n')}`);
      makeBreak();
      // weSay(`If the student picked the correct answer (\`${answer}\`), we say:`);
      function addNMLink(txt: string): string {
        if (!presentingStacker) {
          return txt;
        }
        const logCode = `log("${quizName}", ${taskIndex}, "run-in-stacker", currentTime(), "", currentTime(), null)`;
        const buttonCode = `<a target='_blank' href='${makeUrl(primarySyntax, program)}' onclick='${logCode}'>here</a>`;
        return `${txt}\n\nClick ${buttonCode} to run this program in the Stacker.`;
      }
      // weSay(addNMLink(`${FEEDBACK_CORRECT_ANSWER}\n\n${genericFeedback}`), "encouraging");
      makeBreak();
      for (const userInput of choices) {
        let feedback = (misconceptions || {})[userInput]?.feedback || genericFeedback;
        if (feedback != genericFeedback) {
          weSay(`If the student picked \`${userInput}\`, we say:`);
          weSay(addNMLink(`The answer is \`${answer}\`. ${feedback}`), "warning");
          makeBreak();
        }
      }
      weSay(`If the student picked/entered any other wrong answer, we say:`);
      weSay(addNMLink(`The answer is \`${answer}\`. ${genericFeedback}`), "warning");
      makeBreak();
    }
    makeBreak();
  }
  // weSay(MESSAGE_LOGGING);


  // const takeaways = (messages
  //   .flatMap((m) => {
  //     if (m !== null && m.emotion == "emphasizing") {
  //       return [m.text];
  //     } else {
  //       return [];
  //     }
  //   }));
  // if (takeaways.length > 0) {
  //   const takeaway = `Let's review what we have learned in this tutorial.\n\n<hr/>\n\n` + takeaways.join("\n\n<hr />\n\n");
  //   weSay(takeaway, "emphasizing");
  // }
  request = Request.End();
  do {
    userInput = yield [request, messages];
  } while (userInput === null);
}

// yield [Request, (Message | null)[]]
// return void
// accept string | null
export function* loop(tutorial: Tutorial, enableRunning: () => void): Iterator<[Request, (Message | null)[]], void, string | null> {
  const messages: (Message | null)[] = [];
  function weSay(s: string, e: Emotion = "neutral", disableTranslation?: boolean) {
    messages.push(sysSays(s, e, undefined, disableTranslation));
    return;
  }
  function postProgram(prompt: string, program: string, warnings?: string[]) {
    if (program) {
      prompt += "\n\n```\n" + program + "```\n";
    }
    for (const w of warnings || []) {
      prompt += "\n\n" + w;
    }
    messages.push(sysSays(prompt, "neutral", ["example-input"]));
    return;
  }
  function theySay(s: string, e: Emotion = "neutral") {
    messages.push(usrSays(s, e));
    return;
  }
  function makeBreak() {
    messages.push(null);
  }
  function logEnd() {
    const time = currentTime();
    return log("end-of-tutorial", -1, Request.End(), time, "", time, null);
  }
  const { order, questions } = tutorial;
  let request: Request;
  let userInput: string | null;
  let taskIndex = -1;
  function prefixPromptWithQID(prompt: string) {
    return `<span class="task">Task ${taskIndex + 1}<span class="total"> of ${order.length}</span></span> ${prompt}`;
  }
  for (let taskName of order) {
    taskIndex += 1;
    // console.log(taskName)
    if (taskName.startsWith("keyframe")) {
      enableRunning();
    }
    const quiz = questions[taskName];
    if ("checkboxes" in quiz) {
      // Checkboxes
      let { prompt, checkboxes, feedback } = quiz;
      prompt = prefixPromptWithQID(prompt);
      weSay(prompt, undefined, true);
      const choices = checkboxes.map(([_, c]) => c);
      request = Request.ChooseMany(choices);
      let requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null);
      let responseTime = currentTime();
      let userAnswer: boolean[] = parseJSON(userInput);
      // Make userEntry
      let userEntry = "";
      for (let i = 0; i < choices.length; i++) {
        const [truth, choice] = checkboxes[i];
        const guess = userAnswer[i];
        userEntry += `<div style="display: flex; flex-direction: row; margin: .2ex;"><span style="margin-right: 1ex;">${guess ? "✅" : "🔲"}</span>${choice}</div>\n\n`;
        console.log("choice", choice)
      }
      const falsePositives: string[] = [];
      const falseNegatives: string[] = [];
      for (let i = 0; i < choices.length; i++) {
        const [truth, choice] = checkboxes[i];
        const guess = userAnswer[i];
        if (truth !== guess) {
          if (guess) {
            falsePositives.push(choice);
          } else {
            falseNegatives.push(choice);
          }
        }
      }
      const correct = falseNegatives.length === 0 && falsePositives.length === 0;
      if (correct) {
        theySay(userEntry, "encouraging");
        weSay(FEEDBACK_CORRECT_C_ANSWER)
        log(taskName, taskIndex, request, requestTime, userInput, responseTime, true);
      } else {
        theySay(userEntry, "warning");
        log(taskName, taskIndex, request, requestTime, userInput, responseTime, false);
        let completeFeedback: string = "";
        if (falseNegatives.length > 0) {
          completeFeedback += `You should also have chosen ${smartJoin(falseNegatives.map((c) => `${c}`))}\n\n`;
        }
        if (falsePositives.length > 0) {
          completeFeedback += `You should NOT have chosen ${smartJoin(falsePositives.map((c) => `${c}`))}\n\n`;
        }
        completeFeedback += feedback;
        weSay(completeFeedback, undefined, true);
      }
      request = Request.Confirm(CONFIRM_READY_FOR_NEXT_QUESTION);
      requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null);
      responseTime = currentTime();
      log(taskName, taskIndex, request, requestTime, "", responseTime, null);
    } else if ("confirm" in quiz) {
      let { confirm } = quiz;
      confirm = prefixPromptWithQID(confirm);
      weSay(confirm);
      request = Request.Confirm(CONFIRM_GENERAL);
      let requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null);
      let responseTime = currentTime();
      log(taskName, taskIndex, request, requestTime, "", responseTime, null);
    } else if ("emphasize" in quiz) {
      let { emphasize } = quiz;
      emphasize = prefixPromptWithQID(emphasize);
      weSay(emphasize, "emphasizing");
      request = Request.Confirm(CONFIRM_GENERAL);
      let requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null);
      let responseTime = currentTime();
      log(taskName, taskIndex, request, requestTime, "", responseTime, null);
      weSay(ASK_FOR_FEEDBACK_ON_GOAL_SENTENCES);
      request = Request.Essay();
      requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null);
      responseTime = currentTime();
      theySay(userInput || WHEN_NO_FEEDBACK_ON_GOAL_SENTENCES);
      log(taskName + ".feedback", taskIndex, request, requestTime, userInput, responseTime, null);
      if (userInput !== "") {
        weSay(THANKS_FOR_FEEDBACK);
      }
    } else if ("select_and_comment" in quiz) {
      // Labelling
      let { select_and_comment: prompt } = quiz;
      prompt = prefixPromptWithQID(prompt);
      weSay(prompt);
      let request: Request = Request.Select(["example-input"], 1, 3 + 1);
      let requestTime = currentTime();
      do {
        do {
          userInput = yield [request, messages];
        } while (userInput === null);
      } while (userInput === "");
      let responseTime = currentTime();
      const labelled: number[] = parseJSON(userInput);
      labelled.sort((i, j) => i - j);
      theySay(`(*You selected ${labelled.length} programs*)`);
      log(taskName, taskIndex, request, requestTime, userInput, responseTime, null);
      const programLinks = labelled.map((i) => `[${i}](#message${i})`).join(",");
      if (labelled.length > 1) {
        weSay(`Okay. How do these programs (${programLinks}) support the point?`);
      } else {
        weSay(`Okay. How does this program (${programLinks}) support the point?`);
      }
      request = Request.Essay();
      requestTime = currentTime();
      do {
        do {
          userInput = yield [request, messages];
        } while (userInput === null);
      } while (userInput === "");
      responseTime = currentTime();
      theySay(userInput);
      log(taskName + ".how", taskIndex, request, requestTime, userInput, responseTime, null);
    } else if (!("answer" in quiz)) {
      // Reflection
      let { prompt, feedback } = quiz;
      prompt = prefixPromptWithQID(prompt);
      weSay(prompt);
      let userInput: string | null;
      request = Request.Essay();
      let requestTime = currentTime();
      do {
        do {
          userInput = yield [request, messages];
        } while (userInput === null);
      } while (userInput === "");
      let responseTime = currentTime();
      theySay(userInput);
      log(taskName, taskIndex, request, requestTime, userInput, responseTime, null);
      if (feedback !== undefined) {
        weSay(feedback);
      }
      request = Request.Confirm(CONFIRM_GENERAL);
      requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null);
      responseTime = currentTime();
      log(taskName, taskIndex, request, requestTime, "", responseTime, null);
    } else if ("distractors" in quiz) {
      // PickOne
      let { prompt, program, distractors, answer, feedback } = quiz;
      prompt = prompt || DEFAULT_PROGRAM_QUESTION_TEXT;
      prompt = prefixPromptWithQID(prompt);
      postProgram(prompt, program);
      const choiceTable: [Choice, number, string][] = [answer, ...distractors].
        map((c, i) => {
          return [c, i] as [Choice, number];
        }).
        sort(([choice1, _i1], [choice2, _i2]) => {
          const v1 = valueOfChoice(choice1);
          const v2 = valueOfChoice(choice2);
          return v1.localeCompare(v2);
        }).
        map(([c, i], j) => {
          const letter = "ABCDEFGHIJKLMN"[j];
          return [c, i, letter];
        });
      let request = Request.ChooseOne(choiceTable.map(([c, _i, l]) => {
        if (typeof c === "string") {
          return [`**${l}**. \`${c}\``, c];
        } else {
          const [display, meaning] = c;
          return [`**${l}**. ${display}`, meaning];
        }
      }));
      let requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null || userInput === "");
      let responseTime = currentTime();
      const userAnswer = userInput;
      weSay(
        "<ol type='A'>" +
        choiceTable.map(([s, _i, l]) => `<li><code>${s}</code></li>`).join('\n') +
        "</ol>"
      );
      const markdownOfUserAnswer = "`" + userAnswer + "`";
      let processedFeedback = feedback;
      for (const [s, i, l] of choiceTable) {
        processedFeedback = processedFeedback.replaceAll(`%${i}%`, `**${l}**`);
      }
      processedFeedback = processedFeedback.replaceAll(/%(\d+),(\d+)%/g, (match, p1: string, p2: string) => {
        const i1 = parseInt(p1);
        const i2 = parseInt(p2);
        const j1 = choiceTable.findIndex(([s, i, l]) => i == i1);
        const j2 = choiceTable.findIndex(([s, i, l]) => i == i2);
        const [_s1, _i1, l1] = choiceTable[j1];
        const [_s2, _i2, l2] = choiceTable[j2];
        if (j1 <= j2) {
          return `**${l1}** and **${l2}**`;
        } else {
          return `**${l2}** and **${l1}**`;
        }
      });
      if (userAnswer === valueOfChoice(answer)) {
        theySay(markdownOfUserAnswer, "encouraging");
        log(taskName, taskIndex, request, requestTime, userInput, responseTime, true);
        weSay(FEEDBACK_CORRECT_C_ANSWER + `\n\n${processedFeedback}`);
      } else {
        theySay(markdownOfUserAnswer, "warning");
        log(taskName, taskIndex, request, requestTime, userInput, responseTime, false);
        weSay(`The answer is \`${answer}\`.\n\n${processedFeedback}`);
      }
      request = Request.Confirm(CONFIRM_READY_FOR_NEXT_QUESTION);
      requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null);
      responseTime = currentTime();
      log(taskName, taskIndex, request, requestTime, "", responseTime, null);
    } else {
      // GuessOutput
      const { program, answer, feedback: genericFeedback, incompatible, misconceptions, again } = quiz;
      // 1. show the program and ask for confirmation
      let prompt = DEFAULT_PROGRAM_QUESTION_TEXT;
      prompt = prefixPromptWithQID(prompt);
      let warnings: string[] = [];
      for (const [syntax, { reason: _ }] of Object.entries(incompatible || {})) {
        warnings.push(`<p>⚠️ ${syntax} behaves differently.<p>`);
      }
      postProgram(prompt, program, warnings);
      let request = Request.Confirm(CONFIRM_READY_TO_ANSWER);
      let requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null);
      let responseTime = currentTime();
      log(taskName, taskIndex, request, requestTime, "", responseTime, null);
      // 2. ask for the prediction
      let literals = extractNumbersFromString(program);
      let choices = [...Object.keys(misconceptions || {})];
      choices = addDistractors(answer, choices, literals);
      choices = choices.sort((c1, c2) => {
        const n = c1.length - c2.length;
        return n || c1.localeCompare(c2);
      });
      request = Request.ChooseOneOrOther(choices.map((c: string) => ["`" + c + "`", c]));
      requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null || userInput === "");
      responseTime = currentTime();
      const { isOther, value: predictedResult }: { isOther: boolean, value: string; } = JSON.parse(userInput);
      const predictedResultAsMarkdown = isOther ? "<code>" + predictedResult + "</code>" : "`" + predictedResult + "`";
      theySay(predictedResultAsMarkdown);
      const isCorrect = (predictedResult === answer);
      log(taskName, taskIndex, request, requestTime, userInput, responseTime, isCorrect);
      // 3. (maybe) ask for an explanation
      if (askingExplanation(taskName, isCorrect)) {
        weSay(PROMPT_EXPLANATION(predictedResultAsMarkdown));
        request = Request.Essay();
        requestTime = currentTime();
        do {
          do {
            userInput = yield [request, messages];
          } while (userInput === null);
        } while (userInput === "");
        responseTime = currentTime();
        theySay(userInput);
        log(taskName, taskIndex, request, requestTime, userInput, responseTime, null);
      }
      // 4. give feedback to the student answer.
      function addNMLink(txt: string): string {
        if (!presentingStacker) {
          return txt;
        }
        const logCode = makeStackerLogCode(taskName, taskIndex);
        const buttonCode = `<a target='_blank' href='${makeUrl(primarySyntax, program)}' onclick='${logCode}'>here</a>`;
        return `${txt}\n\nClick ${buttonCode} to run this program in the Stacker.`;
      }
      if (isCorrect) {
        // 4.a when the student is correct
        weSay(addNMLink(`${FEEDBACK_CORRECT_PO_ANSWER}\n\n${genericFeedback}`), "encouraging");
      } else {
        // 4.b when the student is incorrect
        // Give feedback depending on whether the student's answer is recognized.
        // we don't need to normalize predicted result because if they have a hard-coded feedback,
        // they are provided by us
        let feedback = addNMLink(`${(misconceptions || {})[predictedResult]?.feedback || genericFeedback}`);
        feedback = `<details onclick='${makeLogCode(taskName, taskIndex, "see-textual-explanation")}'><summary>Textual explanation</summary>${feedback}</details>`;
        feedback = `The answer is \`${answer}\`. ${feedback}`;
        let feedbackStacker = (misconceptions || {})[predictedResult]?.feedback_stacker;
        if (feedbackStacker !== undefined) {
          feedback += `<details><summary>Graphical explanation</summary>You might also want to check <a href="${feedbackStacker}" target="_blank" onclick='${makeLogCode(taskName, taskIndex, "see-graphical-explanation")}'>a graphical explanation</a></details>`;
        }
        weSay(feedback, "warning");

        if (predictedResult in (misconceptions || {})) {
          request = Request.SimpleChooseOne([CONFIRM_HAVING_READ_EXPLANATION_POS, CONFIRM_HAVING_READ_EXPLANATION_NEG]);
          requestTime = currentTime();
          do {
            userInput = yield [request, messages];
          } while (userInput === null);
          responseTime = currentTime();
          log(taskName, taskIndex, request, requestTime, userInput, responseTime, null);
          if (userInput == CONFIRM_HAVING_READ_EXPLANATION_NEG) {
            weSay(ASK_FOR_FEEDBACK_ON_EXPLANATION);
            request = Request.Essay();
            requestTime = currentTime();
            do {
              userInput = yield [request, messages];
            } while (userInput === null);
            responseTime = currentTime();
            theySay(userInput || WHEN_NO_FEEDBACK_ON_GOAL_SENTENCES);
            log(taskName + ".feedback", taskIndex, request, requestTime, userInput, responseTime, null);
            if (userInput !== "") {
              weSay(THANKS_FOR_FEEDBACK);
            }
          }
        } else {
          request = Request.Confirm(CONFIRM_HAVING_READ_EXPLANATION);
          requestTime = currentTime();
          do {
            userInput = yield [request, messages];
          } while (userInput === null);
          responseTime = currentTime();
          log(taskName, taskIndex, request, requestTime, userInput, responseTime, null);
        }
        makeBreak();


        // Ask a similar question.
        postProgram(DEFAULT_PROGRAM_QUESTION_TEXT, again.program, warnings);
        let first = true;
        do {
          request = Request.ProgramResult();
          requestTime = currentTime();
          do {
            do {
              userInput = yield [request, messages];
            } while (userInput === null);
          } while (userInput === "");
          responseTime = currentTime();
          // console.log(normalizeProgramResult(userInput), normalizeProgramResult(again.answer))
          if (normalizeProgramResult(userInput) === normalizeProgramResult(again.answer)) {
            const markdownOfUserAnswer = "<code>" + userInput + "</code>";
            theySay(markdownOfUserAnswer, "encouraging");
            log(taskName + ".again", taskIndex, request, requestTime, userInput, responseTime, true);
            weSay(FEEDBACK_CORRECT_PO_ANSWER);
            break;
          } else {
            const markdownOfUserAnswer = "<code>" + userInput + "</code>";
            theySay(markdownOfUserAnswer, "warning");
            log(taskName + ".again", taskIndex, request, requestTime, userInput, responseTime, false);
            const message = (first) ? FEEDBACK_WRONG_ANSWER_TO_ISO_QUESTION_FIRST : FEEDBACK_WRONG_ANSWER_TO_ISO_QUESTION_REST;
            weSay(message);
            first = false;
          }
        } while (true);
      }
      request = Request.Confirm(CONFIRM_READY_FOR_NEXT_QUESTION);
      requestTime = currentTime();
      do {
        userInput = yield [request, messages];
      } while (userInput === null);
      responseTime = currentTime();
      log(taskName, taskIndex, request, requestTime, userInput, responseTime, null);
    }
    makeBreak();
  }

  const takeaways = (messages
    .flatMap((m) => {
      if (m !== null && m.emotion == "emphasizing") {
        let text = m.text;
        text = text.replace(
          /<span class="task">Task [0-9]+<span class="total"> of [0-9]+<\/span><\/span> /,
          ""
        );
        return [text];
      } else {
        return [];
      }
    }));
  if (takeaways.length > 0) {
    const takeaway = `Let's review what we have learned in this tutorial.\n\n<hr/>\n\n` + takeaways.join("\n\n<hr />\n\n");
    weSay(takeaway, "emphasizing");
  }
  enableRunning();
  logEnd();
  // Show the final message and goodbye
  request = Request.End();
  do {
    userInput = yield [request, messages];
  } while (userInput === null);

  function smartJoin(choices: string[]) {
    if (choices.length === 0) {
      return "nothing";
    } else if (choices.length === 1) {
      return choices[0];
    } else if (choices.length === 2) {
      return `${choices[0]} and ${choices[1]}`;
    } else {
      const prefix = choices.slice(0, choices.length - 1).map((c) => `"${c}"`).join(", ");
      const final = choices[choices.length - 1];
      return `${prefix}, and ${final}`;
    }
  }
}


function makeLogCode(taskName: string, taskIndex: number, action: any) {
  return `log("${taskName}", ${taskIndex}, ${JSON.stringify(action)}, currentTime(), "", currentTime(), null)`;
}

function makeStackerLogCode(taskName: string, taskIndex: number) {
  return makeLogCode(taskName, taskIndex, "run-in-stacker")
}

function makeChoice(ns: string[]) {
  return (template: string): string[] => {
    const fragments = template.split("???");
    if (fragments.length <= 1) {
      return [template];
    } else {
      let mutations = [fragments[0]];
      for (let i = 1; i < fragments.length; i++) {
        mutations = mutations.flatMap((base) => ns.flatMap((n) => `${base}${n}${fragments[i]}`));
      }
      return mutations;
    }
  };
}

function templateOfChoice(choice: string) {
  return choice.replaceAll(numberRegExp, "???");
}

function addDistractors(answer: string, choices: string[], literals: string[]) {
  const allChoices = distinct([answer, "error", ...choices]);
  if (allChoices.length == 1) {
    // the answer must be error and there is no hard-coded distractors
    return [...allChoices, ...literals];
  }
  const templates = distinct(allChoices.map(templateOfChoice));
  const numberPools: string[] = distinct([
    ...literals,
    ...allChoices.flatMap(extractNumbersFromString)
  ]);
  const possiblyDistractingChoices = shuffle(distinct(templates.flatMap(makeChoice(numberPools))));
  for (const c of possiblyDistractingChoices) {
    if (allChoices.length >= 8) {
      break;
    } else {
      if (allChoices.indexOf(c) < 0) {
        allChoices.push(c);
      }
    }
  }
  return allChoices;
}
