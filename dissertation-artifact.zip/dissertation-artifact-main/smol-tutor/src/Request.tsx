export type Tag = string;
// In the more complicated choice form, the first is markdown, the second is the value
export type Choice = string | [ string, string ]
export function valueOfChoice(c: Choice): string {
    if (typeof c === "string") {
        return c;
    } else {
        return c[1]
    }
}
export type Request =
    RequestEndSession |
    RequestConfirm |
    RequestEssay |
    RequestProgramResult |
    RequestSelect |
    RequestSimpleChooseOne |
    RequestChooseOne |
    RequestChooseOneOrOther |
    RequestChooseMany;
interface RequestEndSession {
    kind: "end",
}
interface RequestConfirm {
    kind: "confirm",
    text: string,
}
interface RequestEssay {
    kind: "essay",
}
interface RequestProgramResult {
    kind: "programResult",
}
interface RequestSelect {
    kind: "select",
    tags: Array<Tag>,
    min: number,
    max: number,
}
interface RequestChooseOne {
    kind: "chooseOne",
    choices: Array<Choice>,
}
interface RequestSimpleChooseOne {
    kind: "simpleChooseOne",
    choices: Array<Choice>,
}
interface RequestChooseOneOrOther {
    kind: "chooseOneOrOther",
    choices: Array<Choice>,
}
interface RequestChooseMany {
    kind: "chooseMany",
    choices: Array<Choice>,
}

export const Request = {
    End: (): Request => {
        return {
            kind: "end",
        }
    },
    Confirm: (text: string): Request => {
        return {
            kind: "confirm",
            text
        };
    },
    Essay: (): Request => {
        return {
            kind: "essay",
        };
    },
    ProgramResult: (): Request => {
        return {
            kind: "programResult",
        };
    },
    Select: (tags: Array<Tag>, min: number, max: number): Request => {
        return {
            kind: "select",
            tags, min, max
        };
    },
    ChooseOne: (choices: Array<Choice>): Request => {
        return {
            kind: "chooseOne",
            choices
        };
    },
    SimpleChooseOne: (choices: Array<Choice>): Request => {
        return {
            kind: "simpleChooseOne",
            choices
        };
    },
    ChooseOneOrOther: (choices: Array<Choice>): Request => {
        return {
            kind: "chooseOneOrOther",
            choices
        };
    },
    ChooseMany: (choices: Array<Choice>): Request => {
        return {
            kind: "chooseMany",
            choices
        };
    },
    case: function <X>(
        request: Request,
        handlers: {
            whenEnd: () => X,
            whenConfirm: (text: string) => X,
            whenEssay: () => X,
            whenProgramResult: () => X,
            whenSelect: (tags: Array<Tag>, min: number, max: number) => X,
            whenSimpleChooseOne: (choices: Array<Choice>) => X,
            whenChooseOne: (choices: Array<Choice>) => X,
            whenChooseOneOrOther: (choices: Array<Choice>) => X,
            whenChooseMany: (choices: Array<Choice>) => X,
        },
    ): X {
        const {
            whenEnd,
            whenConfirm,
            whenEssay,
            whenProgramResult,
            whenSelect,
            whenSimpleChooseOne,
            whenChooseOne,
            whenChooseOneOrOther,
            whenChooseMany,
        } = handlers;
        switch (request.kind) {
            case "end": {
                const { } = request;
                return whenEnd();
            }
            case "confirm": {
                const { text } = request;
                return whenConfirm(text);
            }
            case "essay": {
                const { } = request;
                return whenEssay();
            }
            case "programResult": {
                const { } = request;
                return whenProgramResult();
            }
            case "select": {
                const { tags, min, max } = request;
                return whenSelect(tags, min, max);
            }
            case "simpleChooseOne": {
                const { choices } = request;
                return whenSimpleChooseOne(choices);
            }
            case "chooseOne": {
                const { choices } = request;
                return whenChooseOne(choices);
            }
            case "chooseOneOrOther": {
                const { choices } = request;
                return whenChooseOneOrOther(choices);
            }
            case "chooseMany": {
                const { choices } = request;
                return whenChooseMany(choices);
            }
        }

    }
};