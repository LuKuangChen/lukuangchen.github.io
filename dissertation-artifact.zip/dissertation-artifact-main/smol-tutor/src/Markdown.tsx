import * as React from 'react';
import { useContext } from 'react';
import { allSyntaxes, CodeRunnableContext, primarySyntax, exportFull, syntax } from './GlobalParameters';
// import { tutorial } from './GlobalParameters';
import { translators } from './ImportTranslator';
import { htmlOfMarkdownString } from './MessageWidgets';
import { makeRunButton } from './Utilities';

function javascriptToHTML(s: string) {
  let textAreaDiv = document.createElement('textarea');
  textAreaDiv.textContent = s;
  return textAreaDiv.innerHTML;
}

const escText = (text: string) => {
  // replace quotes because we sometimes embed generated programs
  return JSON.stringify(text).replaceAll("'", "&apos;").replaceAll('"', "&quot;");
};

const STACKER_URL = "https://smol-tutor.xyz/stacker";

export const makeUrl = (syntax: syntax, program: string) => {
  const urlBase = STACKER_URL;
  const params = new URLSearchParams();
  params.set('syntax', syntax);
  params.set('randomSeed', 'smol-tutor');
  params.set('nNext', '0');
  params.set('program', program);
  params.set('readOnlyMode', "");
  return `${urlBase}?${params.toString()}`;
};

function capitalize(str: string) {
  return str.charAt(0).toUpperCase() + str.slice(1);
}

function translateCodeBlock(codeRunnable: boolean, fragment: string, secondarySyntax?: syntax) {
  const translate = (syntax: syntax) => {
    try {
      return "<pre class='code-block'>" + (
        (fragment.startsWith("term"))
          ? translators["Term"][syntax](fragment.substring("term".length))
          : translators["Program"][syntax](true, fragment)
      ) + "</pre>";
    } catch (err) {
      return `<div style="max-width: 25ex"><p>Not applicable. ${err}</p></div>`;
    }
  };
  if (secondarySyntax != undefined) {
    return (
      "<div class='code-block'>" +
      `<div><span class="syntaxName">${primarySyntax}${
        codeRunnable ? " " + makeRunButton(fragment, primarySyntax) : ""
      }</span>` + translate(primarySyntax) + "</div>" +
      `<div><span class="syntaxName">${secondarySyntax}${
        // Only the primary syntax has the run button
        ""
      }</span>` + translate(secondarySyntax) + "</div>" +
      // allSyntaxes.filter((v) => v != primarySyntax && v != secondarySyntax).map((s) => {
      //   return `<div style="width: 0; overflow-x: hidden;"><span class="syntaxName">${s}</span>` + translate(s) + "</div>";
      // }).join("") +
      "</div>"
    );
  } else {
    return (
      translate(primarySyntax)
    );
  }
}

function translate(codeRunnable: boolean, vector: string, src: string, secondarySyntax?: syntax) {
  const dst: Array<string> = [];
  src.split("```").forEach((fragment, index) => {
    if (index % 2 === 1) {
      // translating code block
      dst.push(translateCodeBlock(codeRunnable, fragment, secondarySyntax));
    } else {
      let dstE: Array<string> = [];
      fragment.split(/`/).forEach((fragment, index) => {
        if (index % 2 === 1) {
          if (dstE[dstE.length - 1].endsWith("var")) {
            // if the previous string ends with "var", then
            // 1. remove "var"
            dstE[dstE.length - 1] = dstE[dstE.length - 1].substring(0, dstE[dstE.length - 1].length - "var".length);
            // 2. translate using the name translator
            dstE.push(`${translators["Name"][primarySyntax](fragment)}`);
          } else if (dstE[dstE.length - 1].endsWith("term")) {
            // if the previous string ends with "term", then
            // 1. remove "term"
            dstE[dstE.length - 1] = dstE[dstE.length - 1].substring(0, dstE[dstE.length - 1].length - "term".length);
            // 2. translate using the name translator
            dstE.push(`${translators["Term"][primarySyntax](fragment)}`);
          } else if (dstE[dstE.length - 1].endsWith("verb")) {
            // if the previous string ends with "verb", then
            // 1. remove "verb"
            dstE[dstE.length - 1] = dstE[dstE.length - 1].substring(0, dstE[dstE.length - 1].length - "verb".length);
            // 2. translate using the name translator
            dstE.push(fragment);
          } else {
            dstE.push(`${translators["Output"][primarySyntax](fragment)}`);
          }
        } else {
          dstE.push(fragment.replaceAll("vector", vector).replaceAll("Vector", capitalize(vector)));
        }
      });
      dst.push(dstE.join("`"));
    }
  });
  return dst.join("");
}

function translateMarkdownSource(src: string, codeRunnable: boolean, secondarySyntax?: syntax) {
  let vectorName: Record<syntax, string> = {
    "JavaScript": "array",
    "Python": "array",
    "Scala 3": "buffer",
    "Pseudo": "vector",
    "Lispy": "vector",
  };
  return translate(codeRunnable, vectorName[primarySyntax], src, secondarySyntax);
}

export function Markdown(props: { secondarySyntax?: syntax, src: string; }) {
  const codeRunnable: boolean = useContext(CodeRunnableContext);
  const { secondarySyntax: secondarySyntax, src } = props;
  const translatedHtmlString = htmlOfMarkdownString(translateMarkdownSource(src, codeRunnable, secondarySyntax));

  const parser = new DOMParser();
  const translatedHtmlElement = parser.parseFromString(translatedHtmlString, "text/html");
  for (const preElement of Array.from(translatedHtmlElement.getElementsByTagName("pre"))) {
    preElement.style.userSelect = codeRunnable ? "auto" : "none";
  }

  return (<div style={{
    display: "contents"
  }} dangerouslySetInnerHTML={{ "__html": translatedHtmlElement.body.innerHTML }}></div>);
}

