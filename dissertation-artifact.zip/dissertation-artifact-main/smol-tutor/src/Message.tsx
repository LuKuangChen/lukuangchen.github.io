export type Message = {
  sender: Sender;
  id: number;
  text: string;
  emotion: Emotion;
  timestamp: number;
  tags: string[];
  disableTranslation?: boolean
};
export const Message = {
  new: (sender: Sender, text: string, emotion?: Emotion, tags?: string[], disableTranslation?: boolean): Message => {
    return {
      sender, text, emotion: emotion || "neutral",
      id: nextID(),
      timestamp: Date.now(),
      tags: [...(tags || [])],
      disableTranslation
    };

  }
};
export type Sender = "sys" | "usr";
export type Emotion = "neutral" | "warning" | "encouraging" | "emphasizing";
let id = 0;
function nextID() {
  let tmp = id;
  id += 1;
  return tmp;
}
export function sysSays(s: string, e: Emotion, tags?: string[], disableTranslation?:boolean): Message {
  return Message.new("sys", s, e, tags, disableTranslation);
}
export function usrSays(s: string, e: Emotion): Message {
  return Message.new("usr", s, e);
}
export function textOfMessage(m: Message) {
  return m.text;
}
