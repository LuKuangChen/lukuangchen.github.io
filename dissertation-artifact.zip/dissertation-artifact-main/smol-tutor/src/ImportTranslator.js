import * as SMoL from '@brownplt/smol-translator/src/SMoL.mjs';

function warpProgramTranslator(translate) {
    return (insertingTopLevelPrint, src) => {
        try {
            return translate(insertingTopLevelPrint, src);
        }
        catch ({_1: err}) {
            throw SMoL.TranslateError.toString(err);
        }
    };
}

function warpTranslator(translate) {
    return (src) => {
        try {
            // console.log("translating", src)
            let result = translate(src);
            // console.log("translated", result)
            return result;
        }
        catch (err) {
            console.log("Found error:", err, "while translating ", src);
            // console.log(SMoL.TranslateError.toString(err._1))
            return src;
        }
    };
}

function patch(hardCodedTranslation, translate) {
    return (src) => {
        console.log("patch", arguments);
        return hardCodedTranslation[(typeof src == "string") ? src.trim() : src] || translate(src);
    };
}

function patchProgram(hardCodedTranslation, translate) {
    return (printingTopLevel, src) => {
        // console.log("patchProgram", arguments)
        return hardCodedTranslation[(typeof src == "string") ? src.trim() : src] || translate(printingTopLevel, src);
    };
}

export const Scala3HardCodedTranslation = {
    "(defvar f (lambda (x) (+ x 1)))": "val f = (x : Int) => x + 1",
    "(deffun f (lambda (x) (+ x 1)))": "def f = (x) => x + 1",
    "(defvar f (lambda (f x) (+ x 1)))": "val f = (f : Int, x : Int) => x + 1",
    "((lambda (n)\n   (+ n 1))\n 2)": "((n : Int) => n + 1)(2))",
    "(lambda (n)\n  (+ n 1))": "(n : Int) => n + 1",
    "(deffun (ffx f x)\n  (f (f x)))\n(deffun (inc x)\n  (+ x 1))\n(ffx inc 1)": "def ffx[T](f : (T => T), x : T) =\n  f(f(x))\ndef inc(x : Int) =\n  x + 1\nprintln(ffx(inc, 1))",
    "(deffun (twice f x)\n  (f (f x)))\n(deffun (double x)\n  (+ x x))\n(twice double 1)": "def twice[T](f : (T => T), x : T) =\n  f(f(x))\ndef double(x : Int) =\n  x + x\nprintln(twice(double, 1))",
    "(deffun (f1)\n  5)\n(defvar f2 f1)\n(defvar f3 f2)\n(* (f3) 10)": "def f1 =\n  5\nval f2 = f1\nval f3 = f2\nprintln(f3 * 10)",
    "(deffun (f)\n  42)\n(defvar g f)\n(defvar h g)\n(h)": "def f =\n  42\nval g = f\nval h = g\nprintln(h)",
    "(deffun (f)\n  (defvar n 1)\n  (deffun (dbl)\n    (set! n (* n 2))\n    n)\n  dbl)\n(defvar dbl1 (f))\n(defvar dbl2 (f))\n\n(dbl1)\n(dbl2)\n(dbl1)": "def f(): () => Int =\n  var n = 1\n  def dbl() =\n    n = n * 2\n    n\n  dbl\nvar dbl1 = f()\nvar dbl2 = f()\nprintln(dbl1())\nprintln(dbl2())\nprintln(dbl1())",
    "(deffun (foo)\n  (defvar n 0)\n  (deffun (bar)\n    (set! n (+ n 1))\n    n)\n  bar)\n(defvar f (foo))\n(defvar g (foo))\n\n(f)\n(f)\n(g)": "def foo(): () => Int =\n  var n = 0\n  def bar() =\n    n = n + 1\n    n\n  bar\nvar f = foo()\nvar g = foo()\nprintln(f())\nprintln(f())\nprintln(g())",
    "(deffun (build-dbl)\n  (defvar n 1)\n  (lambda ()\n    (set! n (* n 2))\n    n))\n(defvar dbl1 (build-dbl))\n(defvar dbl2 (build-dbl))\n\n(dbl1)\n(dbl2)\n(dbl1)": "def buildDbl() =\n  var n = 1\n  () =>\n    n = n * 2\n    n\nval dbl1 = buildDbl()\nval dbl2 = buildDbl()\nprintln(dbl1())\nprintln(dbl2())\nprintln(dbl1())",
    "(deffun (foobar)\n  (defvar n 0)\n  (lambda ()\n    (set! n (+ n 1))\n    n))\n(defvar f (foobar))\n(defvar g (foobar))\n\n(f)\n(f)\n(g)": "def foobar(): () => Int =\n  var n = 0\n  () =>\n    n = n + 1\n    n\nvar f = foobar()\nvar g = foobar()\nprintln(f())\nprintln(f())\nprintln(g())",
    "(defvar a (mvec 55 17))\n(deffun (foobar b)\n  (vec-set! b 0 52))\n(foobar a)\na": "val a = Buffer(55, 17)\ndef foobar(b : Buffer[Int]) =\n  b(0) = 52\nfoobar(a)\nprintln(a)",
    "(defvar m1 (mvec 77 77))\n(deffun (f m2)\n  (vec-set! m2 0 43))\n(f m1)\nm1": "var m1 = Buffer(77, 77)\ndef f(m2 : Buffer[Int]) =\n  m2(0) = 43\nf(m1)\nprintln(m1)",
    "(defvar abc (mvec 84 82 85 86))\n(vec-set! abc 1 abc)\n(vec-ref abc 0)": "val abc = Buffer[Any](84, 82, 85, 86)\nabc(1) = abc\nprintln(abc(0))",
    "(defvar m (mvec 82 76))\n(vec-set! m 0 m)\n(vec-ref m 1)": "val m = Buffer[Any](82, 76)\nm(0) = m\nprintln(m(1))",
    "(defvar zz (mvec 88 88))\n(deffun (f aa)\n  (vec-set! aa 0 97))\n(f zz)\nzz": "val zz = Buffer(88, 88)\ndef f(aa : Buffer[Int]) =\n  aa(0) = 97\nf(zz)\nprintln(zz)",
    "(defvar ns (mvec 74 85))\n(vec-set! ns 0 ns)\n(vec-ref ns 1)": "val ns = Buffer[Any](74, 85)\nns(0) = ns\nprintln(ns(1))",
    "(defvar x 7)\n(deffun (fun n)\n  (* n 2))\n(mvec (fun x) x)": "val x = 7\ndef fun(n : Int) =\n  n * 2\nprintln(Buffer(fun(x), x))",
    "(defvar n 44)\n(deffun (f x)\n  (+ x 1))\n(mvec n (f n))": "val n = 44\ndef f(x : Int) =\n  x + 1\nprintln(Buffer(n, f(n)))",
    "(defvar x (mvec 71 86))\n(deffun (f y)\n  (vec-set! y 0 34))\n(f x)\nx": "val x = Buffer(71, 86)\ndef f(y : Buffer[Int]) =\n  y(0) = 34\nf(x)\nprintln(x)",
    "(defvar x (mvec 84 73 69 52))\n(vec-set! x 1 x)\n(vec-ref x 0)": "val x = Buffer[Any](84, 73, 69, 52)\nx(1) = x\nprintln(x(0))",
    "(defvar x (mvec 43 54))\n(vec-set! x 0 x)\n(vec-ref x 1)": "val x = Buffer[Any](43, 54)\nx(0) = x\nprintln(x(1))",
    "(defvar a (mvec 66 54))\n(deffun (h b)\n  (vec-set! a 0 42)\n  b)\n(h a)": "val a = Buffer(66, 54)\ndef h(b : Buffer[Int]) =\n  a(0) = 42\n  b\nprintln(h(a))",
    "(defvar x (mvec 99 83))\n(deffun (f y)\n  (vec-set! x 0 34)\n  y)\n(f x)": "val x = Buffer(99, 83)\ndef f(y : Buffer[Int]) =\n  x(0) = 34\n  y\nprintln(f(x))",
    "(defvar a (mvec 41 92))\n(defvar b (mvec a))\n(vec-set! a 1 b)\n(vec-ref a 0)": "val a = Buffer[Any](41, 92)\nval b = Buffer(a)\na(1) = b\nprintln(a(0))",
    "(defvar x (mvec 74 82))\n(defvar y (mvec x))\n(vec-set! x 0 y)\n(vec-ref x 1)": "val x = Buffer[Any](74, 82)\nval y = Buffer(x)\nx(0) = y\nprintln(x(1))"
};

export const translators = {
    "Name": {
        "JavaScript": warpTranslator(SMoL.JSTranslator.translateName),
        "Python": warpTranslator(SMoL.PYTranslator.translateName),
        "Pseudo": warpTranslator(SMoL.PCTranslator.translateName),
        "Scala 3": warpTranslator(SMoL.SCTranslator.translateName),
        "Lispy": (s) => s
    },
    "Term": {
        "JavaScript": warpTranslator(SMoL.JSTranslator.translateStandAloneTerm),
        "Python": warpTranslator(SMoL.PYTranslator.translateStandAloneTerm),
        "Pseudo": warpTranslator(SMoL.PCTranslator.translateStandAloneTerm),
        "Scala 3": patch(Scala3HardCodedTranslation, warpTranslator(SMoL.SCTranslator.translateStandAloneTerm)),
        "Lispy": (s) => s
    },
    "Program": {
        "JavaScript": warpProgramTranslator(SMoL.JSTranslator.translateProgram),
        "Python": warpProgramTranslator(SMoL.PYTranslator.translateProgram),
        "Pseudo": warpProgramTranslator(SMoL.PCTranslator.translateProgram),
        "Scala 3": patchProgram(Scala3HardCodedTranslation, warpProgramTranslator(SMoL.SCTranslator.translateProgram)),
        "Lispy": (_, s) => s
    },
    "Output": {
        "JavaScript": warpTranslator(SMoL.JSTranslator.translateOutput),
        "Python": warpTranslator(SMoL.PYTranslator.translateOutput),
        "Pseudo": warpTranslator(SMoL.PCTranslator.translateOutput),
        "Scala 3": patch(Scala3HardCodedTranslation, warpTranslator(SMoL.SCTranslator.translateOutput)),
        "Lispy": (s) => s
    },
};
