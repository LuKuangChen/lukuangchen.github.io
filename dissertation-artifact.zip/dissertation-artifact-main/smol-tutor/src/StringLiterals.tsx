export const DEFAULT_PROGRAM_QUESTION_TEXT = "What is the result of running this program?";
export const FEEDBACK_CORRECT_PO_ANSWER = "You predicted the output correctly 🎉🎉🎉";
export const FEEDBACK_CORRECT_C_ANSWER = "You gave the correct answer 🎉🎉🎉";
export const FEEDBACK_WRONG_ANSWER_TO_ISO_QUESTION_FIRST = "Sorry, no, please try again. This program is not radically different from the previous one.";
export const FEEDBACK_WRONG_ANSWER_TO_ISO_QUESTION_REST = "Sorry, no, please try again.";
export const CONFIRM_GENERAL = "Click to continue.";
export const CONFIRM_READY_TO_ANSWER = "I have read the program.";
export const CONFIRM_READY_FOR_NEXT_QUESTION = "I am ready for the next question.";
export const CONFIRM_HAVING_READ_EXPLANATION = "I have read the error message.";
export const CONFIRM_HAVING_READ_EXPLANATION_POS = "The explanation makes sense to me.";
export const CONFIRM_HAVING_READ_EXPLANATION_NEG = "This is not what I thought.";
export const ASK_FOR_FEEDBACK_ON_EXPLANATION = "What is your thought? (Feel free to skip this question.)";
export const PROMPT_EXPLANATION = (answer: string) =>
    `Please briefly explain why you think the answer is ${answer}.`;
export const MESSAGE_END_OF_TUTORIAL = `
You have finished this tutorial 🎉🎉🎉

Please <button style="padding: 0;" onclick="window.print();return false;">print</button> the finished tutorial to a PDF file so you can review the content in the future. **Your instructor (if any) might require you to submit the PDF.**
`;
// export const MESSAGE_END_OF_TUTORIAL = "**Please wait a couple of seconds to let us record your response. There will be a pop-up window when we are done.**";
export const MESSAGE_LEAVE = "You are good to go. Thank you!";
export const MESSAGE_LOGGING_FAILURE = "Something went wrong. But don't worry. You will be asked to download two files. Please send the downloaded file to a TA.";
export const ASK_FOR_FEEDBACK_ON_GOAL_SENTENCES = "Any feedback regarding these statements? Feel free to skip this question.";
export const WHEN_NO_FEEDBACK_ON_GOAL_SENTENCES = "*(You skipped the question.)*"
export const THANKS_FOR_FEEDBACK = "Thank you!"
export const ALL_MAKE_SENSE = "This makes sense."
export const NOT_ALL_MAKE_SENSE = "This doesn't make sense."
export const WHEN_NOT_ALL_MAKE_SENSE = [
    "You can improve the system if you can let us know what confused you. ",
    "Feel free to skip this question."
].join('')
export const WHEN_SKIPPED_WHEN_NOT_ALL_MAKE_SENSE = "*(You skipped the question.)*"
export const THANKS_FOR_WHEN_NOT_ALL_MAKE_SENSE = 'Thank you!'
export const PLACEHOLDER_PROGRAM_RESULT = 'Please enter the program result (e.g., "42 135") ...'
