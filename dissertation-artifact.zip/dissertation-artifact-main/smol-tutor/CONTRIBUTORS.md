My biggest "thank you" shall be given to students who attended [CSCI1730 at Brown](https://cs.brown.edu/courses/cs173/),
especially to those who attended in 2021 and 2022, where early (and rough!) versions of the tutor were deployed.
They provide lots of valuable feedback on materials as well as UI/UX and other aspects.

I also highly appreciate other people who provides feedback after using the tutor.

- Yukai (Johannes) Chou
- Paulo Carvalho
- Andrei Liviu Georgescu

I am greatful for those who have tested a considerable portion of the tutor and/or given very critical feedback.

- [Elijah Rivera](https://www.elijahrivera.com/)
- [Siddhartha Prasad](https://www.siddharthaprasad.com)
- [Yanyan Ren](https://yanyanr.github.io/)
- [Will Crichton](https://willcrichton.net/)
- [TAs of CSCI1730 at Brown in 2022](https://cs.brown.edu/courses/cs173/2022/staff.html):
  - Paul Biberstein
  - Jiahua Chen
  - Ashley Chung
  - Ben Goff
  - Isha Mody
  - Livia Zhu
  - Ocean Pak
  - Sidharth Anand
- Ya-Ching Hsieh
- Filip Strömbäck
- Edwin Florez Gomez
