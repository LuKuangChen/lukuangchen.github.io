# SMoL Tutor

An ITS/CAI for SMoL. This system provides a number of tutorials on various PL concepts.

[Try the Tutor](https://script.google.com/a/macros/google.com/s/AKfycbwXSAkyTGGyYHyM1YTY_UqLfpoXIGMQI3zfCIMjxC2pd9YbEIxhzyf0njwW5rmqPP4lYg/exec)

## Reference to the SMoL Language

https://docs.google.com/document/d/e/2PACX-1vTMVCrUYliicrunyxftDwv6HVmBeKaRW9-VF9Xh1GUFoHMmomOczz_RRIZXPJoH8WB66x-d4GlRvwuy/pub

## Build and run

Dependencies:

- `node.js` (tested with `v16.14.2` and `v16.15.1` on macOS).

These steps build a Tutor

1. Install JavaScript dependencies (React, TypeScript, etc.): `npm install`
2. Build the Tutor: `npm run build`

To open a tutorial, open the `dist/index.html` file with your favorite web browser.
This will open the first tutorial, that is, the `def1` tutorial.
If you want to open tutorials other than the `def1` tutorial,
you need to specify the tutorial name at the end of the URL.
For example, if you want to open the `mutvars1` tutorial, the end of the URL needs to be
`...index.html?tutorial=mutvars1` rather than `...index.html`.
For a complete list of tutorial names, please check [`./src/tutorials/`](./src/tutorials/).

## The most interesting files

To learn more about the tutorials, see

- The source code of the tutorials (written in TOML format): [`./src/tutorials/`](./src/tutorials/)
- The "type"/"schema" of the tutorial format: [`./src/TutorialType.tsx`](./src/TutorialType.tsx)

To customize, see

- Many global parameters (including the default syntax): [./src/GlobalParameters.tsx](./src/GlobalParameters.tsx)
- String literals shared among tutorials: [`./src/StringLiterals.tsx`](./src/StringLiterals.tsx)
- Logging interactions on the tutorials: [`./src/Log.tsx`](./src/Log.tsx)
- Coloring of the UI: [`./src/Color.css`](./src/Color.css)

## Host an instance of the Tutor

You might want to host your own instance of the Tutor for other people
(typically your "students"). This section lists a few options for
hosting.

### Option 1: Host as a static web page

After [Build and Run](#build-and-run), you should be able to open the `dist/index.html`. To host the Tutor, you just need to host the whole directory as a static web page so that other people also have access to the HTML file.

### Option 2: Host with Google Apps Script (GAS)

In comparison to [Option 1](#option-1-host-as-a-static-web-page)

Pros:

* No need to host a static web page.
* Able to collect student responses in a data table, which will make
  it easier to study patterns in student responses.

Cons:

* Need a Google account

Please see https://smol-tutor.xyz/host-with-gas for instructions.

### Option 3: Host with your custom logging system

In comparison to [Option 1](#option-1-host-as-a-static-web-page)

Pros:

* Able to collect student responses in a data table, will make it
  easier to study patterns in student responses.
* Not depend on Google.

Cons:

* Need to prepare a "backend" that accepts and stores student responses.
* Need to write a JavaScript function that sends student responses to the backend.

The option is similar to [Option
2](#option-2-host-with-google-apps-script-gas) but logs data by a
custom logging system rather than by writing to a Google Sheet.

#### Concepts related to logging

When users open a tutorial, they will be asked to do something at the
lowest part of the screen. Typically, the task is clicking a
confirmation button or doing a multiple-choice question. In the source
code, we refer to each task as a `request` and the user's response to
the task as a `response`. Most other things in the source code are
extra information, either about requests or about responses. This
extra information covers which tutorial (`tutorialName`), when the
tutorial was opened (`startTime`), which question the request is about
(`task`), and whether the response is considered correct (`correct`),
among other things.

#### How to customize logging?

Basically, you need to write a JavaScript function that takes the
aforementioned information and sends the information to your storage.

Currently, most deployments of the Tutor work on Google Apps Script, which means
we have a global variable called `google` that can transmit the information.
(See `googleLog` in [`./src/Log.tsx`](./src/Log.tsx)). This is also the *only*
place where the Tutor depends on Google Apps Script.

In the same file, we provide examples of how to log nothing
(`noopLog`), how to log to the browser console (`consoleLog`), and how
to log by sending a POST request (`postLog`).
