const fs = require('fs');

fs.writeFileSync(
  "./GAS/Page.html",
  fs.readFileSync("dist/index.html", "utf-8").replaceAll(
    `<script src="./bundle.js"></script>`,
    [
      `<output id="url-parameters" style="display: none"><?= urlParameters ?></output>`,
      `<?!= include('JavaScript'); ?>`
    ].join("")))

fs.writeFileSync(
  "./GAS/JavaScript.html",
  "<script>" +
  fs.readFileSync("./dist/bundle.js", "utf-8") +
  "</script>"
)