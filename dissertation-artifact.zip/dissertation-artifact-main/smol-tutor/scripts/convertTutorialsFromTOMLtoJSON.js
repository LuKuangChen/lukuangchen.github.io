var toml = require('smol-toml');
const fs = require('fs');

const tutorialNames = [
    "1-def1",
    "1-def2",
    "1-def3",
    "2-vectors1",
    "2-vectors2",
    "2-vectors3",
    "3-mutvars1",
    "3-mutvars2",
    "4-lambda1",
    "4-lambda2",
    "4-lambda3",
    "begin",
    "local",
    "post1",
    "post2",
    "post3",
    "post4",
    "refactor",
    "mini",
];
let tutorials = {}
for (const tn of tutorialNames) {
    let data = fs.readFileSync(`./src/tutorials/${tn}.toml`, 'utf8')
    let shortTn = tn.split("-")
    shortTn = shortTn[shortTn.length - 1];
    data = toml.parse(data);
    tutorials[shortTn] = data;
}
tutorials = JSON.stringify(tutorials, undefined, 2);
fs.writeFileSync(
    "src/tutorials.js",
    `export const tutorials = ${tutorials}`
);
fs.writeFileSync(
    "src/tutorials.json",
    tutorials,
);
