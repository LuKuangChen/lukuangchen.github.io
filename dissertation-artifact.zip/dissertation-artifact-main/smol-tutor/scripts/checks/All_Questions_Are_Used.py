import json

the_tutorial_json = json.load(open("src/tutorials.json", 'r'))

def flatten(xs):
    ys = []
    for x in xs:
        if isinstance(x, list):
            ys = ys + flatten(x)
        else:
            ys.append(x)
    return ys

for (t_name, t_content) in the_tutorial_json.items():
    order = t_content["order"]
    questions = t_content["questions"]
    s1 = set(questions.keys()).difference(set(flatten(order)))
    s2 = set(flatten(order)).difference(set(questions.keys()))
    s = s1.union(s2)
    if len(s):
        print(t_name)
        for x in s:
            print(x)
        print("=====")
