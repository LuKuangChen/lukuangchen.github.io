import json
import subprocess

the_tutorial_json = json.load(open("src/tutorials.json", 'r'))

for (t_name, t_content) in the_tutorial_json.items():
    print("\n## {}".format(t_name))
    for t_task_group in t_content["order"]:

        def do_something(task_name):
            task_content = t_content["questions"][task_name]
            if "program" in task_content and t_name not in ["heap", "local"]:
                print("\n### {}".format(task_name))
                program = task_content["program"]
                print("\n\n```\n{}\n```".format(program))
                the_correct_option = task_content["answer"]
                # get the misconceptions as in the tutor
                misconceptions_in_tutor = task_content.get("misconceptions", {})
                # get the misinterpreter-driven misconceptions
                result = subprocess.run(
                    "echo '{}' | racket scripts/Tag_Answers.rkt".format(program),
                    shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
                miscon_table = result.stdout
                print("\n\n```\n{}\n```".format(miscon_table))
                miscon_table = [
                    list(miscon.split(","))
                    for miscon in miscon_table.split("\n") if miscon != ""
                ]
                misconceptions_by_misinterp = {}
                for [answer, misconception] in miscon_table:
                    if answer not in misconceptions_by_misinterp.keys():
                        misconceptions_by_misinterp[answer] = []
                    misconceptions_by_misinterp[answer].append(misconception)
                # now, compare the two collection of misconceptions and output
                for [ choice, explanation ] in misconceptions_in_tutor.items():
                    explanation = (explanation and explanation.get("feedback")) or "!!MissingExplanation"
                    print("\n**{}**: {}".format(choice, explanation))
                    if choice not in misconceptions_by_misinterp.keys():
                        print("!!NotInMisinterp")
                    else:
                        print("Misconceptions: {}".format(misconceptions_by_misinterp[choice]))
                        if len(misconceptions_by_misinterp[choice]) > 1:
                            print("!!OverlappingChoices")
                for [result, misco_name] in misconceptions_by_misinterp.items():
                    if result not in misconceptions_in_tutor.keys():
                        print("\n**{}**: {}::{}".format(result, "!!MissingExplanation", misco_name))

        if isinstance(t_task_group, list):
            for t_task in t_task_group:
                do_something(t_task)
        else:
            do_something(t_task_group)
