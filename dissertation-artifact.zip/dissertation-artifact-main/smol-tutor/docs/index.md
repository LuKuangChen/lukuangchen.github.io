# SMoL Tutor

SMoL Tutor is a web app that corrects common misconceptions about basic concepts in modern programming languages. Specifically, the tutor teaches you, for example, how to answer the following questions:

- Why does the following program produce an `error` rather than `2` or `3`?

```javascript
let x = 2;
function main() {
  function getX() {
    return x;
  }
  let y = getX();
  let x = 3;
  return y;
}
console.log(main());
```

- Why is `v` evaluated to `[1,2,[4]]` rather than to `[1,2,[3]]`?

```javascript
let x = [ 3 ];
let v = [ 1, 2, x ];
x[0] = 4;
console.log(v);
```

Read [this blog post](https://blog.brownplt.org/2024/04/12/behavior-misconceptions.html) to learn more about the SMoL Tutor.

## Tutorials

These tutorials are hosted with Google Apps Script. *We do record your work in the tutorials to exercises for research purposes, but will not share it with any third parties. We **do not** record your identity.*

Each tutorial typically takes 10-20 min (rarely exceeding 30 min). You can save the finished tutorials to PDF once you finish.
However, you will lose your work *if you close a tutorial in the middle*.

[Here are all tutorials.](https://smol-tutor.xyz/tutor/)

## Changes since 2023

- Added a secondary display for each code block. The secondary display presents the same code in a different syntax.
- Added a tutorial that ask students to think about program behavior in the context of refactoring.
- Added new syntaxes: Scala 3 (not applicable to stacker) and Pseudo (a pseudo-code syntax)
- Some questions now feature a "graphical" refutation text, which pinpoint misconceptions in the context of stacker (a notional machine).

## Changes since 2022

- Added buttons for each code block to see JavaScript/Python translation.
- Replaced the copy-program-with-lang-line buttons with run buttons for running in the new web-based stacker. These buttons interact with the syntax-choosing buttons mentioned above.
- Added a summary of goal sentences at the end of each tutorial.
- Added a "print" button at the end of each tutorial. The buttons save the finished tutorials to a PDF.
- Ensured that all number literals have only two digits to avoid confusion with heap addresses.
- Replaced post-test questions such that their programs are isomorphic to the programs in their corresponding pre-tests.
- "In-lined" the previously external Google forms.
- Added some questions that ask for an explanation on why a program doesn't produce an expected result.
- Improved README on how to customize the logging system.
