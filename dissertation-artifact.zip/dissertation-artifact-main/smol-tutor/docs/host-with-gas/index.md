# How to host SMoL Tutor on your Google Account?

At the end of this process, you will have in your Google Drive

- a Google Sheet that logs tutee inputs
- a Google Apps Script (or Scripts) that hosts the tutor
- a Google Drive folder that contains the file(s) above

## Step 1: Create a Folder (hereafter, "the folder")

Inside your Google Drive, create a new folder. We will use this folder
to store all files.

## Step 2: Create a Google Sheet (hereafter, "the sheet")

### Step 2.1: Create the file

Inside the folder, create a Google Sheet (hereafter, "the sheet"). We
will use this sheet to log student inputs. You might want to give the
sheet a sensible name (e.g., `Logs of SMoL Tutor`).

### Step 2.2: Set up the table header

Set up the header row. Set the row names as

```
User, TutorialStartTime, Tutorial, PositionOfRequest, Task, PositionOfTask, Request, RequestTime, Response, ResponseTime, IsCorrect
```

After pasting (do not right-click!), the `Split text to columns` functionality can be handy: ![Alt
text](image.png)

### Step 2.3: Save the Sheet ID

The URL of the Sheet should look like

```
https://docs.google.com/spreadsheets/d/{ SheetID }/edit
```

The random string between `/d/` and `/edit` is the **Sheet ID**. We will
need the ID to connect the tutor with the sheet.

## Step 3: Upload the tutor

Stay in the sheet, and click `Extensions | Apps Script`. You will find yourself
in an editor:

![Alt text](image-1.png)

You might want to give the GAS a sensible name (e.g., `SMoL Tutor`) because students will see the name.

### Step 3.1 Upload `Code.gs`, `Page.html`, and `JavaScript.html`

A file named `Code.gs` should have been created automatically by Google. Its content should look like

```javascript
function myFunction() {

}
```

Replace the file content with the content of `GAS/Code.gs`.

Please replace `{ YOUR SHEET ID }` (at line 1) with your Sheet ID found
in [Step 2.3](#step-23-save-the-sheet-id).

You will need to create `Page.html` yourself by clicking the `+` button near `Files` and then clicking `HTML`. Please enter `Page` (i.e., without the `.html` suffix) as the file name. Again, you can find the content of this file at `GAS/Page.html` directory. You will need to upload `JavaScript.html` similarly.

### Step 3.2 Deploy the Apps Script

Click `Deploy | New Deployment`, and then deploy as a Web App:
![Alt text](image-3.png)

Configure the deployment so that

- The `Execute as` option is set to **Me**. This allows the Apps
  Script to change the sheet because the sheet is owned by "Me".
- The `Who has access` option is set to **Anyone**.

After clicking `Deploy`, you will be asked to `Authorize Access`.

![Alt text](image-4.png)

The autorization process might look scary:

![Alt text](image-5.png)

If you hit `Go to SMoL Tutor (unsafe)`, you will see that the tutor requests two kinds of access

![Alt text](image-6.png)

The tutor needs access to spreadsheets because it needs to write data to the spreadsheet you just created. (I know no way of requesting access to only one spreadsheet; if you happen to know a way, please let me know!)

It needs access to display and run third-party web content in order to present the SMoL Tutor.

### Step 3.3 Create accessible URL

After hitting deployment, you should be able to see something like:

![Alt text](image-7.png)

Please save the `Deployment ID`. It is critical for dealing a known bug of Google Apps Script.

The `URL` on the screen *might* be able to open the tutor. However, if you have multiple Google accounts logged into the same browser, it is very likely the URL won't work for you. To create a URL that likely work for everyone, you need to fill in the following URL template:

```
https://script.google.com/a/macros/{ YOUR INSTITUTION }/s/{ YOUR DEPLOYMENT ID }/exec
```

The `{ YOUR INSTITUION }` is `google.com` is your Google account ends with `google.com`. However, if you have a institution-owned Google account (in my case, `kuang-chen_lu@brown.edu`), you will need to use whatever that is after `@` (in my case, `brown.edu`).

If you want to send your students direct links to one of the tutorial, you can specify the tutorial as a URL parameter (e.g., `?tutorial=lambda2`).

This URL collects student responses _without collecting their
identities (i.e., their Google accounts)_. If you want to collect
student identities, please proceed to Step 4.

## Step 4 (Optional): Create Entry Points for Logging Student Identities

If you are still reading, you are interested in collecting users'
Google accounts. To this end, we are going to create another GAS insider the folder.

### Step 4.1: Create the Entry Point GAS

Open the folder that we created in [Step 1](#step-1-create-a-folder-hereafter-the-folder).
Create a Google Apps Script:

![Alt text](image-8.png)

### Step 4.2: Configure the Entry Point GAS

Open the GAS and then replace the content of `Code.gs` with

```js
const BASE_LINK =
  "https://script.google.com/a/macros/{ YOUR INSTITUTION }/s/{ YOUR TUTOR GAS ID }/exec";

function doGet(e) {
  var template = HtmlService.createTemplate(HTML_TEMPLATE);
  var userEmail = Session.getActiveUser().getEmail();
  // Retrieve and process any URL parameters, as necessary.
  template.userEmail = userEmail;
  template.link = `${BASE_LINK}?userEmail=${encodeURIComponent(userEmail)}`;
  return template.evaluate().setTitle("Preparing a tutorial for you.");
}

const HTML_TEMPLATE = `<!DOCTYPE html>
<html>
  <body>
    Hi! <?= userEmail ?>, please click <a href="<?= link ?>" target="_blank">here</a> to open the tutor.
  </body>
</html>
`;
```

Remember to replace `{ YOUR INSTITUTION }` and `{ YOUR TUTOR GAS ID }`.

You might want to give the GAS a sensible name (e.g., `Open SMoL Tutor`) because students will see it.

### Step 4.3: Deploy the Entry Point GAS

Click `Deploy | New Deployment`, and then deploy as a Web App:
![Alt text](image-3.png)

Configure the deployment so that

- The `Execute as` option is set to **User accessing the web app**.
  This allows this GAS to collect its users' Google accounts.
- The `Who has access` option is set to **Anyone with Google account**.

After clicking `Deploy`, you will be given another `Deployment ID` and another `URL`.

![Alt text](image-9.png)

After that, please click `Done` to finish the first deploy.

### Step 4.5 Create accessible URL

Again, the `URL` on the screen *might* be able to open the tutor. However, if you have multiple Google accounts logged into the same browser, it is very likely the URL won't work for you. To create a URL that likely work for everyone, you need to fill in the following URL template:

```
https://script.google.com/a/macros/{ YOUR INSTITUTION }/s/{ YOUR DEPLOYMENT ID }/exec
```

The `{ YOUR INSTITUION }` is `google.com` is your Google account ends with `google.com`. However, if you have a institution-owned Google account (in my case, `kuang-chen_lu@brown.edu`), you will need to use whatever that is after `@` (in my case, `brown.edu`).

### Step 5: Test the Tutor

I strongly recommend to check whether all GASes and the Sheet are
connected properly:

Open the URL constructed in [Step
4.4] (or [Step
3.4] if you choose not to log
student identities), _preferably with a different Google account_.

You will see a request for authorization:

![Alt text](image-10.png)

If you click `REVIEW PERMISSION`, you will be brought to the GAS
directly. This might sound scary because it seems that the GAS somehow
prevents its users from reviewing permissions. But this actually means
there is no special permissions required.

After getting into the (Entry Point) GAS, you should see something like

![Alt text](image-11.png)

And if you click `here`, you will see a table of tutorials. If you open one of the tutorials and submit some answers, you should be able to find your answers logged in the Sheet.
