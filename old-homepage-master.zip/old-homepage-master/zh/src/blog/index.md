# 呂廣振的博客

歡迎！

* <a href="./自學樂理其一.xhtml">自學樂理（一）</a>
* <a href="./两条路.xhtml">两条路</a>
* <a href="./严输入严输出.xhtml">严输入严输出</a>
* <a href="./近期計劃.xhtml">近期計劃</a>
* <a href="./UNIX系統的一些問題.xhtml">UNIX系統的一些問題</a>
* <a href="./嘗試創作編程教程.xhtml">嘗試創作編程教程</a>
* <a href="./歧视与消灭它们的方法.xhtml">歧视与消灭它们的方法</a>
* <a href="./生信还是CS.xhtml">再次思考学科的抉择：生物信息学vs计算机科学</a>
* <a href="./重建博客.xhtml">重建博客</a>
