2017-03-05

最近突然又有興緻學習匯編語言。因為偏愛簡介的設計，就選擇了RISC。我在SPARC、RISC-V和MIPS中選擇了MIPS。因為它的教程與工具都更容易取得。這裡我想推薦一個講MIPS的網站：

<a href="http://chortle.ccsu.edu/AssemblyTutorial/index.html">Programmed Introduction to MIPS Assembly Language</a>
